<?php
        $pR2truDrAw = true;     // tajna zmienna potrzebna do zainkludowania plików
	include 'inc/gora.php';

        $zebra=0;

	// Domyślne wartości, odpowiednio liczby rekordów na strone i przesunięcia
	$count=200;
	$offset=0;

	if(isset($_GET['page'])&&is_numeric($_GET['page'])&&(($_GET['page'])>0)){$offset=$count*mysql_real_escape_string(htmlspecialchars(addslashes(($_GET['page']-1)),ENT_QUOTES));}

	// Pobranie liczby rekordów
	$lr=dbquery("SELECT count(*) FROM wardriving","count(*)");
	// Liczba stron, użycie ceil - zaokrąglenie w górę, w celu zapewnienia, że żadna strona się nie straci
	$pages=ceil($lr/$count);

	$sort=$_GET['sort'];
	$order=$_GET['order'];
	if(!isset($_GET['sort'])) {$sort="seen";}
	if(!isset($_GET['order'])) {$order="desc";}
	if($sort=="ssid") {if($order=="desc") {$query="SELECT * FROM wardriving ORDER BY ssid DESC LIMIT ".$count." OFFSET ".$offset."";}else {$query="SELECT * FROM wardriving ORDER BY ssid LIMIT ".$count." OFFSET ".$offset."";}}
	elseif($sort=="bssid") {if($order=="desc") {$query="SELECT * FROM wardriving ORDER BY bssid DESC LIMIT ".$count." OFFSET ".$offset."";}else {$query="SELECT * FROM wardriving ORDER BY bssid LIMIT ".$count." OFFSET ".$offset."";}}
	elseif($sort=="encrypt") {if($order=="desc") {$query="SELECT * FROM wardriving ORDER BY encryption1 DESC LIMIT ".$count." OFFSET ".$offset."";}else {$query="SELECT * FROM wardriving ORDER BY encryption1 LIMIT ".$count." OFFSET ".$offset."";}}
	elseif($sort=="city") {if($order=="desc") {$query="SELECT * FROM wardriving ORDER BY admarea2 DESC LIMIT ".$count." OFFSET ".$offset."";}else {$query="SELECT * FROM wardriving ORDER BY admarea2 LIMIT ".$count." OFFSET ".$offset."";}}
	elseif($sort=="seen") {if($order=="desc") {$query="SELECT * FROM wardriving ORDER BY seen DESC LIMIT ".$count." OFFSET ".$offset."";}else {$query="SELECT * FROM wardriving ORDER BY seen LIMIT ".$count." OFFSET ".$offset."";}}
	else {$query="SELECT * FROM wardriving ORDER BY seen DESC LIMIT ".$count." OFFSET ".$offset."";$sort="seen";}

	$result=mysql_query($query);
	$num=mysql_num_rows($result);

	echo "<table class=\"db\" border=\"0\" cellpadding=\"5\" cellspacing=\"1\" width=\"100%\">";

	if($order=="desc"){$negorder="asc";}
	else {$negorder="desc";}

	for($i=0;$i<$pages;$i++){
	if($i*$count==$offset){
			echo "\n<tr><th><a href=\"db.php?page=".($i+1)."&amp;sort=bssid&amp;order=".$negorder."\">BSSID</a></th><th><a href=\"db.php?page=".($i+1)."&amp;sort=ssid&amp;order=".$negorder."\">Nazwa sieci (SSID)</a></th><th>#</th><th><a href=\"db.php?page=".($i+1)."&amp;sort=encrypt&amp;order=".$negorder."\">Sposób szyfrowania</a></th><th><a href=\"db.php?page=".($i+1)."&amp;sort=city&amp;order=".$negorder."\">Pozycja GPS</a></th></tr>\n<!-- Copyright © Adam Ziaja. All Rights Reserved. -->\n";
		}
	}
	
	$i=0;
	while ($i < $num) {
		$bssid=mysql_result($result,$i,"bssid");

		$ssid=htmlspecialchars(mysql_result($result,$i,"ssid"),ENT_QUOTES);

		$cloaked=mysql_result($result,$i,"cloaked");
			if($cloaked=="true") {$cloaked="<span class=\"szary\">nazwa sieci została ukryta</span>";}
			if($cloaked=="false") {$cloaked="";}

		$channel=mysql_result($result,$i,"channel");
		    if($channel=="0") {$channel="<span class=\"szary\">?</span>";}

		$encryption1=mysql_result($result,$i,"encryption1");
		$encryption2=mysql_result($result,$i,"encryption2");
		$encryption3=mysql_result($result,$i,"encryption3");
			if($encryption1=="None") {$encryption1="<span class=\"zielony\">brak szyfrowania</span>";}
			if(substr($encryption1,0,3)=="WEP") {$encryption1="<span class=\"niebieski\">".$encryption1."</span>";}
			if(substr($encryption1,0,3)=="WPA") {if($encryption1!="") {$encryption1="<span class=\"czerwony\">".$encryption1."</span>";}}
			if(substr($encryption2,0,3)=="WPA") {if($encryption2!="") {$encryption2="<span class=\"czerwony\">".$encryption2."</span>";}}
			if(substr($encryption3,0,3)=="WPA") {if($encryption3!="") {$encryption3="<span class=\"czerwony\">".$encryption3."</span>";}}
		if($encryption2!="") {$encryption2=", ".$encryption2."";}
		if($encryption3!="") {$encryption3=", ".$encryption3."";}
		$encryption=($encryption1.$encryption2.$encryption3);

		$gpslat=mysql_result($result,$i,"gpslat");
		$gpslon=mysql_result($result,$i,"gpslon");
		$gpslatDECtoDMS=DECtoDMS($gpslat);
		$gpslonDECtoDMS=DECtoDMS($gpslon);
		$gps=($gpslat.",".$gpslon);
		$gpsDECtoDMS=($gpslatDECtoDMS.",".$gpslonDECtoDMS);

		$address=mysql_result($result,$i,"address");
			if (!empty($address)) {$address="<span class=\"zielony\" title=\"Jest adres\">A</span>";}
			if (empty($address)) {$address="<span class=\"szary\" title=\"Brak adresu\">A</span>";}
		
		echo "<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><td><a href=\"ap.php?bssid=$bssid\">$bssid</a></td><td>$ssid$cloaked</td><td>$channel</td><td>$encryption</td><td><a href=\"http://maps.google.pl/maps?q=$gps\" target=\"_blank\">$gpsDECtoDMS</a> $address</td></tr>\n";
 
	$i++;
	}
	
	echo "</table>\n<br><div style=\"text-align:center;\">\n";

	// Pętla po stronach
	for($i=0;$i<$pages;$i++){
	// Jeśli obecna strona, nie twórz linku do strony
	if($i*$count==$offset){
			echo ($i+1)." \n";
		}else{
			//echo ' <a href="db.php?count='.$count.'&offset='.($i+1).'">'.($i+1).'</a> ';
			echo "<a href=\"db.php?page=".($i+1)."&amp;sort=".$sort."&amp;order=".$order."\">".($i+1)."</a> \n";
		}
	}

	echo "</div>\n";
	include 'inc/dol.php';
?>
