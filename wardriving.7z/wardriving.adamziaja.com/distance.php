<?php

function distance2($latA, $lonA, $latB, $lonB)
{
    $latA = deg2rad($latA);
    $lonA = deg2rad($lonA);
    $latB = deg2rad($latB);
    $lonB = deg2rad($lonB);
    $deltaLat = ($latA - $latB);
    $deltaLon = ($lonA - $lonB);
    $d = sin($deltaLat/2) * sin($deltaLat/2) +
        cos($latA) * cos($latB) * sin($deltaLon/2) * sin($deltaLon/2);
    $d = 2 * asin(sqrt($d));
    return $d * 6371.01;
}

set_time_limit(0);

    $files = glob('./gps/Kismet-*.gpsxml');
    $suma_all = 0;
    foreach ($files as $kismetlog) {
        if (file_exists($kismetlog)) {
        $gps_ary = array();
        $sum_gps = 0;
        $prev_gps = '';
        $xml=simplexml_load_file($kismetlog);
        //echo "<p>".$kismetlog."</p>";
            foreach ($xml->{'gps-point'} as $gpspoint) {
                if ($gpspoint['bssid']=="GP:SD:TR:AC:KL:OG") {
                    $gpslat=$gpspoint['lat'];
                    $gpslon=$gpspoint['lon'];
                    $gps=$gpslat.",".$gpslon;
                    $gps_ary[] = $gps;
                }
            }

    foreach($gps_ary as $k => $v)
    {
        $a = explode(',', $v);
        $b = explode(',', $k < count($gps_ary)-1 ? $gps_ary[$k+1] : $prev_gps);
        $result = distance2($a[0], $a[1], $b[0], $b[1]);
        //echo $result;
        $sum_gps += $result;
        $prev_gps = $v;
    }
    echo $kismetlog . ' - ' . $sum_gps . 'km<br>';
    $suma_all += $sum_gps;
        }
    }

    echo '<p>Suma wszystkich: ' . $suma_all . 'km</p>';

?>
