<?php
    $pR2truDrAw = true;     // tajna zmienna potrzebna do zainkludowania plik�w

	require "inc/connection.php";
    connection();

	include 'inc/gps.php';

	$getlat=htmlspecialchars($_GET["lat"]);
	$getlon=htmlspecialchars($_GET["lon"]);
	$lat=round($getlat,3);
	$lon=round($getlon,3);
	$minlat=$lat-0.008;
	$maxlat=$lat+0.008;
	$minlon=$lon-0.008;
	$maxlon=$lon+0.008;
	echo "lat\tlon\ttitle\tdescription\ticon\ticonSize\n";
	$query="SELECT * FROM wardriving WHERE gpslat BETWEEN \"".$minlat."\" AND \"".$maxlat."\" AND gpslon BETWEEN \"".$minlon."\" AND \"".$maxlon."\"";

	$result=mysql_query($query);
	$num=mysql_numrows($result);
	mysql_close();

	$i=0;
	while ($i < $num) {
		$bssid=mysql_result($result,$i,"bssid");
		$ssid=htmlspecialchars(mysql_result($result,$i,"ssid"));
		$cloaked=mysql_result($result,$i,"cloaked");
			if($cloaked=="true") {$cloaked="<span style=\"color:#A9A9A9\">ukryta</span>";}
			if($cloaked=="false") {$cloaked="";}
			//if($cloaked=="false") {$cloaked="<span style=\"color:green\">widoczna</span>";}
		$channel=mysql_result($result,$i,"channel");
		$encryption1=mysql_result($result,$i,"encryption1");
			if($encryption1!="WEP" && $encryption1!="None") {$icon="/img/mm_20_red.png";}
			if($encryption1=="None") {$encryption1="<span style=\"color:green\">brak</span>";$icon="/img/mm_20_green.png";}
			if($encryption1=="WEP") {$encryption1="<span style=\"color:blue\">".$encryption1."</span>";$icon="/img/mm_20_blue.png";}
		$encryption2=mysql_result($result,$i,"encryption2");
		$encryption3=mysql_result($result,$i,"encryption3");
			if(strncmp("WPA",($encryption1||$encryption2||$encryption3),3)) {
				if($encryption1!="") {$encryption1="<span style=\"color:red\">".$encryption1."</span>";}
				if($encryption2!="") {$encryption2="<span style=\"color:red\">".$encryption2."</span>";}
				if($encryption3!="") {$encryption3="<span style=\"color:red\">".$encryption3."</span>";}
			}
		if($encryption2!="") {$encryption2=", ".$encryption2."";}
		if($encryption3!="") {$encryption3=", ".$encryption3."";}
		$encryption=($encryption1.$encryption2.$encryption3);
		$gpslat=mysql_result($result,$i,"gpslat");
		$gpslon=mysql_result($result,$i,"gpslon");
		$seen=mysql_result($result,$i,"seen");

		echo "$gpslat\t$gpslon\t$bssid\t<b>Nazwa</b>:<br>$ssid$cloaked<br><b>Kana&#322;</b>: $channel<br><b>Szyfrowanie</b>:<br>$encryption<br><b>Ostatnio widziana</b>:<br>$seen\t$icon\t12,20\n";
 
	$i++;
}
 
?>
