<?php
    $pR2truDrAw = true;     // tajna zmienna potrzebna do zainkludowania plików
	include 'inc/gora.php';
?>
<div style="text-align:justify">
<ul>
<li><a href="http://wardrive.pl" target="_blank">wardrive.pl</a><br></li>
<li><a href="http://wardriving-forum.de" target="_blank">wardriving-forum.de</a> (thanks to <a href="http://www.salecker.org" target="_blank">Patrick Salecker</a>!)<br></li>
<li><a href="http://kismetwireless.net" target="_blank">kismetwireless.net</a><br></li>
<li><a href="https://docs.google.com/document/pub?id=1urAb1Z3WYNjmnZ5lnOyWXVc7yirBQwKCuGBtJODyB0s" target="_blank" >wardriving nie jest przestępstwem</a></li>
</ul>
</div>
<?php include 'inc/dol.php'; ?>
