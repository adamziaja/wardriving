<?php
	// sprawdzenie czy zmienna istnieje
	if(!$pR2truDrAw) exit;

// konfiguracja
//$wardriving_db="wardriving";
//$parser_db="parser";
//$logi_db="log";

function connection() {
    $mysql_server = "localhost";
    $mysql_admin = "xxx";
    $mysql_pass = "xxx";
    $mysql_db = "wardriving";
    @mysql_connect($mysql_server, $mysql_admin, $mysql_pass)
    or die('Brak połączenia z serwerem MySQL.');
    @mysql_select_db($mysql_db)
    or die('Błąd wyboru bazy danych.');
}

// zapytanie dla pojedyńczych wartości
// dbquery("zapytanie","kolumna");
// dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'neostrada\_____'", "count(*)");
function dbquery($query,$col) {
	$sql=mysql_query($query);
	$row=mysql_fetch_array($sql);
	return $row[$col];
}

date_default_timezone_set('Europe/Warsaw'); // Warning: date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier.

?>
