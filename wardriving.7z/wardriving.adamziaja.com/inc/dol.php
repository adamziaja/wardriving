<?php
	// sprawdzenie czy zmienna istnieje
	if(!$pR2truDrAw) exit;
?>
<!-- środek - koniec -->
</div>
        <div id="pietro5" class="pietro5">Copyright &copy; 2010-2011 <a href="http://adamziaja.com" target="_blank">Adam Ziaja</a>. All rights reserved.</div>
        <!-- <div id="pietro6" class="pietro6"><a href="http://validator.w3.org/check?uri=referer">Valid HTML 4.01 Strict</a>, <a href="http://jigsaw.w3.org/css-validator/check?uri=referer&amp;profile=css3">Valid CSS level 3</a></div> -->
    <!-- blok - koniec -->
    </div>
<!-- stat - początek -->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-21262994-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<!-- stat - koniec -->
</body>
</html>
