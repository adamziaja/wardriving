<?php
        header('X-Frame-Options: DENY');

	// sprawdzenie czy zmienna istnieje
	if(!$pR2truDrAw) exit;

	// połącznie z bazą
	require "inc/connection.php";
	connection();

	// GPS
	include 'inc/gps.php';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Language" content="pl">
    <meta name="Keywords" content="mapy sieci bezprzewodowych, wardriving, warchalking, warxing, wireless, wifi">
    <meta name="Description" content="wardriving, warchalking">
    <meta name="Author" content="Adam Ziaja">
    <meta name="Robots" content="INDEX, FOLLOW">
    <title>mapy sieci bezprzewodowych &bull; wardriving &amp; warchalking</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <div id="blok">
    <!-- blok - początek -->
        <div id="pietro1" class="pietro1"><a href="index.php">mapy sieci bezprzewodowych</a></div>
        <div id="pietro2mieszkanie1" class="pietro2mieszkanie1">baza zawiera dane <b><?php echo dbquery("SELECT count(*) FROM wardriving","count(*)"); ?></b> sieci bezprzewodowych</div>
        <div id="pietro2mieszkanie2" class="pietro2mieszkanie2">ostatnia aktualizacja bazy <b><?php echo date("Y-m-d",strtotime(dbquery("SELECT adddate FROM parser ORDER BY adddate DESC LIMIT 1","adddate"))); ?></b> <a href="rss.php"><img src="img/rss.png" width="14" height="14" alt="RSS" style="vertical-align:top;border:0;"></a></div>
        <div id="pietro3" class="pietro3">
            <div class="menu">
                <ul>
                    <li><a href="/">strona główna</a></li><li><a href="maps.php" target="_blank">interaktywne mapy sieci</a></li><li><a href="staticmaps.php">statyczne mapy sieci</a></li><li><a href="db.php">baza sieci</a></li><li><a href="search.php">wyszukiwarka sieci</a></li><li><a href="stats.php">statystyki sieci</a></li><li><a href="contact.php">kontakt</a></li><!-- <li><a href="links.php">odnośniki</a></li> -->
                </ul>
            </div>
        </div>
<div id="pietro4" class="pietro4">
<!-- środek - początek -->
