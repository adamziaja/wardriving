<?php
    $pR2truDrAw = true;     // tajna zmienna potrzebna do zainkludowania plików
	include 'inc/gora.php';
?>
<div style="text-align:justify">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Pojęcie <b>wardriving</b> oznacza wyszukiwanie miejsc w których dostępne są sieci bezprzewodowe przez osobę poruszającą się pojazdem z przenośnym komputerem lub innym urządzeniem umożliwiającym wyszukiwanie bezprzewodowych sieci, takim jak np. PDA czy Smartphone. Najbardziej popularnym oprogramowaniem do wardrivingu jest <b>Kismet</b> pod system operacyjny Linux oraz <b>NetStumbler</b> pod system Windows. Wardriving wymyślił Peter Shipley w okolicach lat 1999-2000, który jako pierwszy zautomatyzował cały proces z dedykowanym oprogramowaniem oraz odbiornikiem <b>GPS</b>, który w momencie znalezienia sieci zapisywał pozycję z GPS, co pozwoliło mu na stworzenie pierwszych <b>map sieci bezprzewodowych</b>.<br><br><div style="text-align:center"><img src="sig.png" border="0" alt=""></div><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Warchalking</b> wymyślił Matt Jones w 2002 roku, pojęcie oznacza oznaczanie miejsc w których dostępne są <b>sieci bezprzewodowe</b>. Pojęcie powstało przez analogię do słowa wardriving. Pierwotnym założeniem było oznaczanie miejsc po przez rysowanie kredą specjalnych symboli w miejscu w którym wykryto siec bezprzewodową, jednak warchalking ewoluował i dziś sprowadza się głównie do oznaczania sieci na <b>interaktywnych mapach</b>.<br><br><div style="text-align:center"><img src="scheme.png" alt="schemat"></div>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Poniższe mapy prezentują przejechaną przeze mnie trasę na dzień 2011-02-27, około <a href="gps.txt" target="_blank">733.6 km</a>.<br><br>
<table border="0" cellpadding="5" cellspacing="0" width="100%">
<tr style="background-color: white">
        <td align="right">
        <a href="maps/gps-google.png" target="_blank"><img src="img/gps-google.jpg" border="0" width="300" height="335" alt="GPS" title="GPS"></a>
        </td>
        <td align="center">
        <a href="maps/gps-osm.png" target="_blank"><img src="img/gps-osm.jpg" border="0" width="300" height="335" alt="GPS" title="GPS"></a>
        </td>
        <td align="left">
        <a href="maps/gps-ump.png" target="_blank"><img src="img/gps-ump.jpg" border="0" width="300" height="335" alt="GPS" title="GPS"></a>
        </td>
</tr>
<tr align="center" style="background-color: white">
        <td>@ Google</td>
        <td>@ OSM</td>
        <td>@ UMP-pcPL</td>
</tr>
<tr align="center" style="background-color: white">
        <td colspan="3"><!-- prezentacja - początek --><div style="width:595px" id="__ss_8248821"><iframe src="http://www.slideshare.net/slideshow/embed_code/8248821?startSlide=2" width="595" height="497" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></div><!-- prezentacja - koniec --><br>Jeśli wykorzystasz mój sposób opisany w powyższej prezentacji to proszę o umieszczenie informacji oraz odnośnika <a href="http://wardriving.adamziaja.com">wardriving.adamziaja.com</a>.</td>
</tr>
</table>
</div>
<?php include 'inc/dol.php'; ?>
