<?php
    $pR2truDrAw = true;     // tajna zmienna potrzebna do zainkludowania plik�w

	require "inc/connection.php";
    connection();

	header("Content-Type: text/xml");

	$result = mysql_query("SELECT adddate FROM parser ORDER BY adddate DESC LIMIT 5");

	echo "<?xml version=\"1.0\" encoding=\"ISO-8859-2\"?>\n\n";
	echo "<!DOCTYPE rss PUBLIC \"-//Netscape Communications//DTD RSS 0.91//EN\"\n";
	echo " \"http://my.netscape.com/publish/formats/rss-0.91.dtd\">\n\n";
	echo "<rss version=\"0.92\">\n\n";
	echo "<channel>\n";
	echo "<title>mapy sieci bezprzewodowych</title>\n";
	echo "<link>http://wardriving.adamziaja.com</link>\n";
	echo "<description>wardriving &amp; warchalking</description>\n";
	echo "<language>pl</language>\n\n";

	while ($row = mysql_fetch_array($result)) {
		$adddate = $row['adddate'];
		echo "<item>\n";
		echo "<title>".$adddate."</title>\n";
		echo "<link>http://wardriving.adamziaja.com</link>\n";
		echo "<description>Aktualizacja ".$adddate."</description>\n";
		echo "</item>\n\n";
	}
	echo "</channel>\n";
	echo "</rss>";
?>
