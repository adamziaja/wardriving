<?php
    $pR2truDrAw = true;     // tajna zmienna potrzebna do zainkludowania plików
	include 'inc/gora.php';

    $all=dbquery("SELECT count(*) FROM wardriving","count(*)");

    // Wszystkie sieci
    $statall=dbquery("SELECT count(*) FROM wardriving","count(*)");
    echo ("Ilość znalezionych sieci:"."&nbsp;".$statall."<br><br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE encryption1 = 'None'","count(*)");
	//$chartw1=round((($stat/$statall)*100),3);
    echo ("Ilość sieci bez szyfrowania:"."&nbsp;".$stat." (".round((($stat/$statall)*100),3)."%)<br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE encryption1 LIKE 'WEP%'","count(*)");
	//$chartw2=round((($stat/$statall)*100),3);
    echo ("Ilość sieci z szyfrowaniem WEP:"."&nbsp;".$stat." (".round((($stat/$statall)*100),3)."%)<br>\n");
    echo ("<span class=\"szary\">-- szyfrowanie złamane</span><br>\n");

    $statwpa=dbquery("SELECT count(*) FROM wardriving WHERE encryption1 LIKE 'WPA%'","count(*)");
	//$chartw3=round((($stat/$statall)*100),3);
    echo ("Ilość sieci z szyfrowaniem WPA:"."&nbsp;".$statwpa." (".round((($statwpa/$statall)*100),3)."%)<br>\n");
    echo ("<span class=\"szary\">-- szyfrowanie WPA1 złamane, WPA2 dotychczas nie złamane</span><br><br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE encryption1 LIKE '%PSK%' OR encryption2 LIKE '%PSK%' OR encryption3 LIKE '%PSK%' AND encryption1 != 'None' AND encryption1 NOT LIKE 'WEP%'","count(*)");
    echo ("Ilość sieci WPA Personal (PSK):"."&nbsp;".$stat." (".round((($stat/$statwpa)*100),2)."% WPA)<br>\n");
    echo ("<span class=\"szary\">-- klienci współdzielą klucz</span><br>\n");
    $stat=dbquery("SELECT count(*) FROM wardriving WHERE encryption1 NOT LIKE '%PSK%' AND encryption2 NOT LIKE '%PSK%' AND encryption3 NOT LIKE '%PSK%' AND encryption1 != 'None' AND encryption1 NOT LIKE 'WEP%'","count(*)");
    echo ("Ilość sieci WPA Enterprise (RADIUS):"."&nbsp;".$stat." (".round((($stat/$statwpa)*100),2)."% WPA)<br>\n");
    echo ("<span class=\"szary\">-- każdy klient otrzymuje własny klucz</span><br><br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE encryption1 LIKE '%TKIP%' OR encryption2 LIKE '%TKIP%' OR encryption3 LIKE '%TKIP%' AND encryption1 != 'None' AND encryption1 NOT LIKE 'WEP%'","count(*)");
    echo ("Ilość sieci WPA1 TKIP:"."&nbsp;".$stat."<br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE encryption1 LIKE '%AES%' OR encryption2 LIKE '%AES%' OR encryption3 LIKE '%AES%' AND encryption1 != 'None' AND encryption1 NOT LIKE 'WEP%'","count(*)");
    echo ("Ilość sieci WPA2 AES:"."&nbsp;".$stat."<br>\n");
    echo ("<span class=\"szary\">-- większość AP udostępnia oba (WPA1/WPA2) sposoby szyfrowania jednocześnie</span><br><br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE encryption1 NOT LIKE '%TKIP%' AND encryption2 NOT LIKE '%TKIP%' AND encryption3 NOT LIKE '%TKIP%' AND encryption1 != 'None' AND encryption1 NOT LIKE 'WEP%'","count(*)");
    echo ("Ilość sieci wyłącznie z szyfrowaniem WPA2 AES:"."&nbsp;".$stat." (".round((($stat/$statall)*100),2)."%)<br>\n");
    echo ("<span class=\"szary\">-- jedyny bezpieczny sposób szyfrowania</span><br>\n");
    echo ("Ilość względnie słabo zabezpieczonych sieci:"."&nbsp;".($statall-$stat)." (".round(((($statall-$stat)/$statall)*100),2)."%)<br>\n");

	//echo ("<img src=\"http://chart.apis.google.com/chart?cht=p3&chs=250x100&chd=t:".$chartw1.",".$chartw2.",".$chartw3."&chl=brak|WEP|WPA\" alt=\"Google Chart\">\n");

	// Miasta
    echo ("<br>Miasta wg ilości występowania:<br>");
	$query="SELECT admarea3 FROM wardriving GROUP BY admarea3 ORDER BY COUNT(admarea3) DESC;";
	$result=mysql_query($query);
    $num=mysql_num_rows($result);
    $i=0;
    while ($i < $num) {
		$admarea3=mysql_result($result,$i,"admarea3"); // admarea3 - miasto, admarea2 - powiat, admarea1 - województwo
		$count=dbquery("SELECT count(*) FROM wardriving WHERE admarea3 = '".$admarea3."'","count(*)");
		  if($admarea3=="") {
			  $admarea3="<span class=\"szary\">brak danych</span>";
			  $count=dbquery("SELECT count(*) FROM wardriving WHERE admarea3 = '' OR admarea3 IS NULL","count(*)");
		  }
		$numer=$i;
        $numer++;
        echo "$numer. $admarea3 - $count (".round((($count/$all)*100),2)."%)<br>\n";
	$i++;
    }

	// Powiaty
    echo ("<br>Powiaty wg ilości występowania:<br>");
	$query="SELECT admarea2 FROM wardriving GROUP BY admarea2 ORDER BY COUNT(admarea2) DESC;";
	$result=mysql_query($query);
    $num=mysql_num_rows($result);
    $i=0;
    while ($i < $num) {
		$admarea2=mysql_result($result,$i,"admarea2"); // admarea3 - miasto, admarea2 - powiat, admarea1 - województwo
		$count=dbquery("SELECT count(*) FROM wardriving WHERE admarea2 = '".$admarea2."'","count(*)");
		  if($admarea2=="") {
			  $admarea2="<span class=\"szary\">brak danych</span>";
			  $count=dbquery("SELECT count(*) FROM wardriving WHERE admarea2 = '' OR admarea2 IS NULL","count(*)");
		  }
		$numer=$i;
        $numer++;
        echo "$numer. $admarea2 - $count (".round((($count/$all)*100),2)."%)<br>\n";
	$i++;
    }

	// Województwa
    echo ("<br>Województwa wg ilości występowania:<br>");
	$query="SELECT admarea1 FROM wardriving GROUP BY admarea1 ORDER BY COUNT(admarea1) DESC;";
	$result=mysql_query($query);
    $num=mysql_num_rows($result);
    $i=0;
    while ($i < $num) {
		$admarea1=mysql_result($result,$i,"admarea1"); // admarea3 - miasto, admarea2 - powiat, admarea1 - województwo
		$count=dbquery("SELECT count(*) FROM wardriving WHERE admarea1 = '".$admarea1."'","count(*)");
		  if($admarea1=="") {
			  $admarea1="<span class=\"szary\">brak danych</span>";
			  $count=dbquery("SELECT count(*) FROM wardriving WHERE admarea1 = '' OR admarea1 IS NULL","count(*)");
		  }
		$numer=$i;
        $numer++;
        echo "$numer. $admarea1 - $count (".round((($count/$all)*100),2)."%)<br>\n";
	$i++;
    }

    // Kanały
    echo ("<br>Kanały wg ilości występowania:<br>");
    $query="SELECT channel,count(*) FROM wardriving GROUP BY channel ORDER BY COUNT(channel) DESC LIMIT 14";
    $result=mysql_query($query);
    $num=mysql_num_rows($result);
    $i=0;
    while ($i < $num) {
        $channel=mysql_result($result,$i,"channel");
		    if($channel=="0") {$channel="<span class=\"szary\">?</span>";}
        $count=mysql_result($result,$i,"count(*)");
        $numer=$i;
        $numer++;
		//$chartch[$numer]=round((($count/$all)*100),3);
		//$chartchannel[$numer]=$channel;
        echo "$numer. Kanał $channel - $count (".round((($count/$all)*100),3)."%)<br>\n";
    $i++;
    }

	$num++;
	/*for($i=6;$i<$num;$i++) {
		$chartch[$i];
		$chartchleft=$chartchleft+$chartch[$i];
	}

	echo ("<img src=\"http://chart.apis.google.com/chart?cht=p3&chs=250x100&chd=t:".$chartch[1].",".$chartch[2].",".$chartch[3].",".$chartch[4].",".$chartch[5].",".$chartchleft."&chl=kana%C5%82%20".$chartchannel[1]."|kana%C5%82%20".$chartchannel[2]."|kana%C5%82%20".$chartchannel[3]."|kana%C5%82%20".$chartchannel[4]."|kana%C5%82%20".$chartchannel[5]."|reszta\" alt=\"Google Chart\">\n");*/

    // Prędkość
    echo ("<br>Prędkość:<br>");
    $query="SELECT maxrate,count(*) FROM wardriving WHERE maxrate !=0 GROUP BY maxrate ORDER BY COUNT(maxrate) DESC";
    $result=mysql_query($query);
    $num=mysql_num_rows($result);
    $i=0;
    while ($i < $num) {
        $maxrate=mysql_result($result,$i,"maxrate");
        $count=mysql_result($result,$i,"count(*)");
        $numer=$i;
        $numer++;
		//$chartmr[$numer]=round((($count/$all)*100),3);
		//$chartmaxrate[$numer]=$maxrate;
        echo "$numer. $maxrate Mb/s - $count (".round((($count/$all)*100),3)."%)<br>\n";
    $i++;
    }

	$num++;
	/*for($i=6;$i<$num;$i++) {
		$chartmr[$i];
		$chartmrleft=$chartmrleft+$chartmr[$i];
	}

	echo ("<img src=\"http://chart.apis.google.com/chart?cht=p3&chs=250x100&chd=t:".$chartmr[1].",".$chartmr[2].",".$chartmr[3].",".$chartmr[4].",".$chartmr[5].",".$chartmrleft."&chl=".$chartmaxrate[1]."%20Mb/s|".$chartmaxrate[2]."%20Mb/s|".$chartmaxrate[3]."%20Mb/s|".$chartmaxrate[4]."%20Mb/s|".$chartmaxrate[5]."%20Mb/s|reszta\" alt=\"Google Chart\">\n");*/

    // SSID
    echo ("<br>Dziesięć najczęściej występujących SSID:<br>");
    $query="SELECT ssid,count(*) FROM wardriving GROUP BY ssid ORDER BY COUNT(ssid) DESC LIMIT 11";
    $result=mysql_query($query);
    $num=mysql_num_rows($result);
    $i=0;
    while ($i < $num) {
        $ssid=mysql_result($result,$i,"ssid");
        $count=mysql_result($result,$i,"count(*)");
            if($ssid!=""){
                echo "$i. $ssid - $count (".round((($count/$all)*100),3)."%)<br>\n";
            }
    $i++;
    }

    // Producent
    echo ("<br>Dziesięć najczęściej występujących producentów:<br>");
    $query="SELECT manuf,count(*) FROM wardriving GROUP BY manuf ORDER BY COUNT(manuf) DESC LIMIT 10";
    $result=mysql_query($query);
    $num=mysql_num_rows($result);
    $i=0;
    while ($i < $num) {
        $manuf=mysql_result($result,$i,"manuf");
        $count=mysql_result($result,$i,"count(*)");
		$i++;
            if($manuf!=""){
                echo "$i. $manuf - $count (".round((($count/$all)*100),3)."%)<br>\n";
            }
    }

    // Neostrada
    $statall=dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'neostrada\_____'","count(*)");
    echo ("<br>Ilość Neostrad ze standardowym SSID:"."&nbsp;".$statall."<br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'neostrada\_____' AND encryption1 = 'None'","count(*)");
    echo ("Ilość Neostrad bez szyfrowania:"."&nbsp;".$stat." (".round((($stat/$statall)*100),3)."%)<br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'neostrada\_____' AND encryption1 LIKE 'WEP%'","count(*)");
    echo ("Ilość Neostrad z szyfrowaniem WEP:"."&nbsp;".$stat." (".round((($stat/$statall)*100),3)."%)<br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'neostrada\_____' AND encryption1 LIKE 'WPA%'","count(*)");
    echo ("Ilość Neostrad z szyfrowaniem WPA:"."&nbsp;".$stat." (".round((($stat/$statall)*100),3)."%)<br>\n");

    // Kanały Neostrada
    echo ("Ilość Neostrad występujących na poszczególnych kanałach:<br>");
    $query="SELECT channel,count(*) FROM wardriving WHERE ssid LIKE 'neostrada\_____' GROUP BY channel ORDER BY COUNT(channel) DESC";
    $result=mysql_query($query);
    $num=mysql_num_rows($result);
    $i=0;
    while ($i < $num) {
        $channel=mysql_result($result,$i,"channel");
        $count=mysql_result($result,$i,"count(*)");
        $numer=$i;
        $numer++;
        echo "$numer. Kanał $channel - $count (".round((($count/$statall)*100),3)."%)<br>\n";
    $i++;
    }

    // Netia
    $statall=dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'NETIA\-%'","count(*)");
    echo ("<br>Ilość Netii ze standardowym SSID:"."&nbsp;".$statall."<br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'NETIA\-%' AND encryption1 = 'None'","count(*)");
    echo ("Ilość Netii bez szyfrowania:"."&nbsp;".$stat." (".round((($stat/$statall)*100),3)."%)<br>\n");
    
    $stat=dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'NETIA\-%' AND encryption1 LIKE 'WEP%'","count(*)");
    echo ("Ilość Netii z szyfrowaniem WEP:"."&nbsp;".$stat." (".round((($stat/$statall)*100),3)."%)<br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'NETIA\-%' AND encryption1 LIKE 'WPA%'","count(*)");
    echo ("Ilość Netii z szyfrowaniem WPA:"."&nbsp;".$stat." (".round((($stat/$statall)*100),3)."%)<br>\n");

    // Kanały Netia
    echo ("Ilość Netii występujących na poszczególnych kanałach:<br>");
    $query="SELECT channel,count(*) FROM wardriving WHERE ssid LIKE 'NETIA\-%' GROUP BY channel ORDER BY COUNT(channel) DESC";
    $result=mysql_query($query);
    $num=mysql_num_rows($result);
    $i=0;
    while ($i < $num) {
        $channel=mysql_result($result,$i,"channel");
        $count=mysql_result($result,$i,"count(*)");
        $numer=$i;
        $numer++;
        echo "$numer. Kanał $channel - $count (".round((($count/$statall)*100),3)."%)<br>\n";
    $i++;
    }

    // UPC
    $statall=dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'UPC______'","count(*)");
    echo ("<br>Ilość UPC ze standardowym SSID:"."&nbsp;".$statall."<br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'UPC______' AND encryption1 = 'None'","count(*)");
    echo ("Ilość UPC bez szyfrowania:"."&nbsp;".$stat." (".round((($stat/$statall)*100),3)."%)<br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'UPC______' AND encryption1 LIKE 'WEP%'","count(*)");
    echo ("Ilość UPC z szyfrowaniem WEP:"."&nbsp;".$stat." (".round((($stat/$statall)*100),3)."%)<br>\n");

    $stat=dbquery("SELECT count(*) FROM wardriving WHERE ssid LIKE 'UPC______' AND encryption1 LIKE 'WPA%'","count(*)");
    echo ("Ilość UPC z szyfrowaniem WPA:"."&nbsp;".$stat." (".round((($stat/$statall)*100),3)."%)<br>\n");

    // Kanały UPS
    echo ("Ilość UPC występujących na poszczególnych kanałach:<br>");
    $query="SELECT channel,count(*) FROM wardriving WHERE ssid LIKE 'UPC______' GROUP BY channel ORDER BY COUNT(channel) DESC";
    $result=mysql_query($query);
    $num=mysql_num_rows($result);
    $i=0;
    while ($i < $num) {
        $channel=mysql_result($result,$i,"channel");
        $count=mysql_result($result,$i,"count(*)");
        $numer=$i;
        $numer++;
        echo "$numer. Kanał $channel - $count (".round((($count/$statall)*100),3)."%)<br>\n";
    $i++;
    }

include 'inc/dol.php';

?>
