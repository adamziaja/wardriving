<?php
    $pR2truDrAw = true;     // tajna zmienna potrzebna do zainkludowania plików
	include 'inc/gora.php';
?>
<table border="0" cellpadding="5" cellspacing="0" width="100%">
<tr style="background-color: white">
	<td align="right">
	<a href="maps/katowice-google.png" target="_blank"><img src="img/katowice-google.jpg" border="0" width="300" height="335" alt="Katowice" title="Katowice"></a>
	</td>
	<td align="center">
	<a href="maps/katowice-osm.png" target="_blank"><img src="img/katowice-osm.jpg" border="0" width="300" height="335" alt="Katowice" title="Katowice"></a>
	</td>
	<td align="left">
	<a href="maps/katowice-ump.png" target="_blank"><img src="img/katowice-ump.jpg" border="0" width="300" height="335" alt="Katowice" title="Katowice"></a>
	</td>
</tr>
<tr align="center" style="background-color: white">
	<td><b>Katowice</b> @ Google</td>
	<td><b>Katowice</b> @ OSM</td>
	<td><b>Katowice</b> @ UMP-pcPL</td>
</tr>
</table>
<?php include 'inc/dol.php'; ?>
