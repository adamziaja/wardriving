<?php
    $pR2truDrAw = true;     // tajna zmienna potrzebna do zainkludowania plików
	include 'inc/gora.php';

	// sprawdzamy, czy zmienna $submit jest pusta
	if (empty($_POST['submit'])) {
		// wyświetlamy formularz
	echo "<div style=\"text-align:center;\"><b>Adam Ziaja</b> &lt;<a href=\"http://www.google.com/recaptcha/mailhide/d?k=01jSRKw_a-GTJVBEDoblKVfQ==&amp;c=iaO584k4-9j5_-EgIlNX3jmeM0Dot_4J4oOefowxUCA=\" target=\"_blank\">reCAPTCHA</a>&gt;<br><br>
	<div style=\"text-align:justify;font-style:italic;\">Nie zajmuję się sprzedażą internetu jak również nie posiadam żadnych danych poza tymi, które dostępne są na stronie, co za tym idzie, nie posiadam np. telefonów kontaktowych do właścicieli sieci. Nie udostępniam kodów źródłowych projektu. Nie udzielam wywiadów na temat wardrivingu dziennikarzom, którzy chcą pisać historie nasączone pseudo sensacją - wardriving jest całkowicie legalny w Polsce i nie ma NIC wspólnego z łamaniem zabezpieczeń sieci bezprzewodowych. Nie udzielam również informacji na temat łamania jakichkolwiek zabezpieczeń.</div><br><div style=\"text-align:justify;font-style:italic;\">W przypadku jeśli otrzymam plik netxml z programu Kismet mogę wygenerować dedykowane mapy, jak np. dla <a href=\"http://wardriving.adamziaja.com/lublin/\" target=\"_blank\">Lublina</a> czy <a href=\"http://wardriving.adamziaja.com/glowno/\" target=\"_blank\">Głowna</a>.</div><br>
	<form method=\"post\" action=\"?\">
	<div style=\"padding-bottom:0.5em\">Treść wiadomości:</div>
	<div><textarea name=\"tresc\" cols=\"50\" rows=\"10\"></textarea></div>
	<div style=\"padding-top:1em;padding-bottom:0.5em\">Imię i nazwisko lub pseudonim:</div>
	<div><input type=\"text\" name=\"imie\" size=\"26\" maxlength=\"50\"></div>
	<div style=\"padding-top:1em;padding-bottom:0.5em\">Adres e-mail:</div>
	<div><input type=\"text\" name=\"email\" size=\"26\" maxlength=\"50\"></div>
	<div style=\"padding-top:1em\"><input type=\"submit\" name=\"submit\" value=\"Wyślij\"></div>
	</form></div>";
	}
	// sprawdzamy, czy zmienne przesłane z formularza nie są puste
	elseif (!empty($_POST['tresc']) && !empty($_POST['imie']) && !empty($_POST['email'])) {
		// jeżeli powyższy warunek jest spełniony tworzona jest wiadomość
		// zmienna $message zawiera treść wiadomości
		$message = "Treść wiadomości:\n$_POST[tresc]\nWysłał: $_POST[imie]\ne-mail: $_POST[email]";
		// zmienna $header zawiera przede wszystkim adres zwrotny
		$header = "From: $_POST[imie] <$_POST[email]>";
		// funkcja mail() za pomocą której wiadomość zostanie wysłana
		@mail("aziaja@gmail.com","wardriving.adamziaja.com","$message","$header")
		or die('Nie udało się wysłać wiadomości');
		// wyświetlenie komunikatu w przypadku powodzenia 
		echo "<div style=\"text-align:center;\" class=\"zielony\">Wiadomość została wysłana poprawnie.<br><br><a href=\"?\">&laquo;&nbsp;wróć</a></div>";
	}
	// lub w przypadku nie wypełnienia formularza do końca
	else echo "<div style=\"text-align:center;\" class=\"czerwony\">Błąd, wypełnij wszystkie pola formularza.<br><br><a href=\"?\">&laquo;&nbsp;wróć</a></div>";
	include 'inc/dol.php';
?>
