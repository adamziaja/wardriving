<?php
    $pR2truDrAw = true;     // tajna zmienna potrzebna do zainkludowania plików

    require "inc/connection.php";
    connection();

	$statall=dbquery("SELECT count(*) FROM wardriving","count(*)");
	$statopen=dbquery("SELECT count(*) FROM wardriving WHERE encryption1 = 'None'","count(*)");
	$statwep=dbquery("SELECT count(*) FROM wardriving WHERE encryption1 LIKE 'WEP%'","count(*)");
	$statwpa=dbquery("SELECT count(*) FROM wardriving WHERE encryption1 LIKE 'WPA%'","count(*)");
	//
	header('Content-type: image/png');
	$obrazek=ImageCreate(234,60); // 468 × 60 (Full Banner), 234 × 60 (Half Banner), http://pl.wikipedia.org/wiki/Banner
	ImageInterlace($obrazek,1); // Obrazek z przeplotem jest to obrazek który ładuje się w kilku etapach. Dzięki temu taki obrazek widac już zanim się cały załaduje.
	//
	$czcionka_georgia='/home/adam/wardriving.adamziaja.com/fonts/Georgia.ttf'; // duża/mała litera!
	$czcionka_verdana='/home/adam/wardriving.adamziaja.com/fonts/Verdana.ttf';
	$czcionka_arial='/home/adam/wardriving.adamziaja.com/fonts/Arial.ttf';
	//
	$kolor_bialy=ImageColorAllocate($obrazek,255,255,255);
	$kolor_czarny=ImageColorAllocate($obrazek,0,0,0);
	$kolor_czerwony=ImageColorAllocate($obrazek,255,0,0);
	$kolor_zielony=ImageColorAllocate($obrazek,0,190,0);
	$kolor_niebieski=ImageColorAllocate($obrazek,0,0,255);
	$kolor_szary=ImageColorAllocate($obrazek,200,200,200);
	//
	ImageFill($obrazek,0,0,$kolor_bialy);
	// cień pierwszy - żeby był pod
	ImageTTFText($obrazek,9,0,6,16,$kolor_szary,$czcionka_georgia,"WARDRIVING & WARCHALKING"); // cień +1/+1
	//ImageTTFText($obrazek,9,0,261,16,$kolor_szary,$czcionka_verdana,"http://wardriving.adamziaja.com");
	ImageTTFText($obrazek,8,0,121,41,$kolor_szary,$czcionka_verdana,"} $statall APs");
	ImageTTFText($obrazek,8,0,6,28,$kolor_szary,$czcionka_verdana,"OPN $statopen (".round((($statopen/$statall)*100),1)."%)");
	ImageTTFText($obrazek,8,0,6,41,$kolor_szary,$czcionka_verdana,"WEP $statwep (".round((($statwep/$statall)*100),1)."%)");
	ImageTTFText($obrazek,8,0,6,54,$kolor_szary,$czcionka_verdana,"WPA $statwpa (".round((($statwpa/$statall)*100),1)."%)");
	//
	ImageTTFText($obrazek,9,0,5,15,$kolor_czarny,$czcionka_georgia,"WARDRIVING & WARCHALKING");
	//ImageTTFText($obrazek,9,0,260,15,$kolor_czarny,$czcionka_verdana,"http://wardriving.adamziaja.com");
	ImageTTFText($obrazek,8,0,5,27,$kolor_zielony,$czcionka_verdana,"OPN $statopen (".round((($statopen/$statall)*100),1)."%)");
	ImageTTFText($obrazek,8,0,5,40,$kolor_niebieski,$czcionka_verdana,"WEP $statwep (".round((($statwep/$statall)*100),1)."%)");
	ImageTTFText($obrazek,8,0,120,27,$kolor_czarny,$czcionka_verdana,"}");
	ImageTTFText($obrazek,8,0,120,40,$kolor_czarny,$czcionka_verdana,"} $statall APs");
	ImageTTFText($obrazek,8,0,120,53,$kolor_czarny,$czcionka_verdana,"}");
	ImageTTFText($obrazek,8,0,5,53,$kolor_czerwony,$czcionka_verdana,"WPA $statwpa (".round((($statwpa/$statall)*100),1)."%)");
	//ImageTTFText($obrazek,6.5,90,229,59,$kolor_czarny,$czcionka_arial,"adamziaja.com");
	//
	$znaczek=imagecreatefrompng('img/wifi-router.png');
	$marge_right=3; // marginesy znaczka
	$marge_bottom=0;
	$sx=imagesx($znaczek); // wymiary znaczka
	$sy=imagesy($znaczek);
	imagecopy($obrazek,$znaczek,imagesx($obrazek)-$sx-$marge_right,imagesy($obrazek)-$sy-$marge_bottom,0,0,imagesx($znaczek),imagesy($znaczek));
	//
	ImagePng($obrazek);
	ImageDestroy($obrazek);
?>
