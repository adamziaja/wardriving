<?php

$REMOTE_ADDR=addslashes($_SERVER['REMOTE_ADDR']);
$HTTP_USER_AGENT=addslashes($_SERVER['HTTP_USER_AGENT']);
$REQUEST_URI=addslashes($_SERVER['REQUEST_URI']);
$DATE=addslashes(date('d.m.Y H:i'));
$HTTP_REFERER=addslashes($_SERVER['HTTP_REFERER']);

$dane = $REMOTE_ADDR."\n".$HTTP_USER_AGENT."\n".$REQUEST_URI."\n".$DATE."\n".$HTTP_REFERER."\n\n";
// przypisanie zmniennej $file nazwy pliku
$file = "log.txt";
// uchwyt pliku, otwarcie do dopisania
$fp = fopen($file, "a");
// blokada pliku do zapisu
flock($fp, 2);
// zapisanie danych do pliku
fwrite($fp, $dane);
// odblokowanie pliku
flock($fp, 3);
// zamknięcie pliku
fclose($fp);

//////////////////////////////////////////////////

session_start();
//session_register("xEpEcr5baWar");

if(empty($_SESSION["xEpEcr5baWar"])){$_SESSION["xEpEcr5baWar"]=0;}

if(isset($_GET['logout'])){$_SESSION["xEpEcr5baWar"]=0;ShowLogin("<p class=\"zielony\">Wylogowano!</p>");die;}

function ShowLogin($komunikat=""){
   echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n<html>\n<head>\n    <meta http-equiv=\"Content-type\" content=\"text/html; charset=utf-8\">\n    <title>mapy sieci bezprzewodowych &bull; wardriving &amp; warchalking</title>\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../css/styles.css\">\n</head>\n<body>\n";
   echo "$komunikat";
   if(!isset($_GET['logout'])){
      echo "<p><form action='?' method=post>";
      echo "Has&#322;o:&nbsp;<input type=password name=password>&nbsp;";
      echo "<input type=submit value='Zaloguj'>";
      echo "</form></p>";
   }
   echo "\n</body>\n</html>";
}

if($_SESSION["xEpEcr5baWar"]!=1338){ // tajne dane
   if(!empty($_POST["password"])){
      if($_POST["password"]=="tr6vECaD5sTA"){$_SESSION["xEpEcr5baWar"]=1338;} else {ShowLogin("<p class=\"czerwony\">Złe hasło!</p>");die;}
   } else {ShowLogin();die;}
}

?>
