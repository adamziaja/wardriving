<?php
    $pR2truDrAw = true; // tajna zmienna potrzebna do zainkludowania plików
	require 'access.php';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Language" content="pl">
    <meta name="Author" content="Adam Ziaja">
    <meta name="Robots" content="NOINDEX, NOFOLLOW">
    <title>mapy sieci bezprzewodowych &bull; wardriving &amp; warchalking</title>
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
<?php
	require "../inc/connection.php";
	connection();

    set_time_limit(0); // Maximum execution time of 30 seconds exceeded
	
	// goto - The goto operator is available as of PHP 5.3.
	//geocode: {

	$query="SELECT * FROM wardriving WHERE admarea1 IS NULL OR admarea2 IS NULL OR address IS NULL ORDER BY seen DESC";
	$result=mysql_query($query);
	$num=mysql_num_rows($result);

	$i=0;
	while ($i < $num) {

		$gpslat=mysql_result($result,$i,"gpslat");
		$gpslon=mysql_result($result,$i,"gpslon");

                // OVER_QUERY_LIMIT - początek
                /*if ($torify % 2 == 0) {
		        shell_exec("torify wget -q -O /tmp/".$gpslat.",".$gpslon.".xml 'http://maps.googleapis.com/maps/api/geocode/xml?latlng=".$gpslat.",".$gpslon."&sensor=false&region=pl&language=pl'");
		        $xmltmp=file_get_contents("/tmp/".$gpslat.",".$gpslon.".xml");
                        sleep(3);
                } else {*/
                        $xmltmp=file_get_contents("http://maps.googleapis.com/maps/api/geocode/xml?latlng=".$gpslat.",".$gpslon."&sensor=false&region=pl&language=pl");
                        /*sleep(3);
                }
                $torify++;*/
                // OVER_QUERY_LIMIT - koniec

		$xml=simplexml_load_string($xmltmp);
		if($xml->status==OK){
			//echo $gpslat.",".$gpslon."<br>";
			foreach ($xml->result[0]->address_component as $obj) if($obj->type[0]==administrative_area_level_3) {$admarea3=$obj->long_name;} // admarea3 - miasto
			foreach ($xml->result[0]->address_component as $obj) if($obj->type[0]==administrative_area_level_2) {$admarea2=$obj->long_name;} // admarea2 - powiat
			foreach ($xml->result[0]->address_component as $obj) if($obj->type[0]==administrative_area_level_1) {$admarea1=$obj->long_name;} // admarea1 - województwo
			$address=$xml->result[0]->formatted_address;

			mysql_query("UPDATE wardriving SET admarea3='".addslashes($admarea3).
						"',"."admarea2='".addslashes($admarea2).
						"',"."admarea1='".addslashes($admarea1).
						"',"."address='".addslashes($address).
						"' WHERE gpslat='".$gpslat."' AND gpslon='".$gpslon."';");
			//sleep(25);
		} else {
			echo "Błąd ".$xml->status."<br>";
			if($xml->status==OVER_QUERY_LIMIT){ sleep(10); } // OVER_QUERY_LIMIT
		}

	$i++;
	}
	// goto
	//}
	
	$query="SELECT * FROM wardriving WHERE admarea1 IS NULL OR admarea2 IS NULL OR address IS NULL ORDER BY seen DESC";
	$result=mysql_query($query);
	$num=mysql_num_rows($result);
	// goto - The goto operator is available as of PHP 5.3.
	//if(0<$num) { goto geocode; } else { echo "<p>Gotowe!</p>"; }
	if(1<=$num) {echo "<p class=\"czerwony\">$num sieci nie są zgeocodowane! <a href=\"?\">Ponów próbę</a>.</p>";} else {echo "<p class=\"zielony\">Wszystkie sieci zgeocodowane!</p>";}

	include 'inc/dol.php';

?>
