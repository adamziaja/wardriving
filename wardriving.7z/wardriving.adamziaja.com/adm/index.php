<?php

$REMOTE_ADDR=addslashes($_SERVER['REMOTE_ADDR']);
$HTTP_USER_AGENT=addslashes($_SERVER['HTTP_USER_AGENT']);
$REQUEST_URI=addslashes($_SERVER['REQUEST_URI']);
$DATE=addslashes(date('d.m.Y H:i'));
$HTTP_REFERER=addslashes($_SERVER['HTTP_REFERER']);

$dane = $REMOTE_ADDR."\n".$HTTP_USER_AGENT."\n".$REQUEST_URI."\n".$DATE."\n".$HTTP_REFERER."\n\n";
// przypisanie zmniennej $file nazwy pliku
$file = "honeypot.txt";
// uchwyt pliku, otwarcie do dopisania
$fp = fopen($file, "a");
// blokada pliku do zapisu
flock($fp, 2);
// zapisanie danych do pliku
fwrite($fp, $dane);
// odblokowanie pliku
flock($fp, 3);
// zamknięcie pliku
fclose($fp);

//////////////////////////////////////////////////

        // sprawdzamy, czy zmienna $submit jest pusta
        if (empty($_POST['submit'])) {
        // wyświetlamy formularz
	echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n<html>\n<head>\n    <meta http-equiv=\"Content-type\" content=\"text/html; charset=utf-8\">\n    <title>mapy sieci bezprzewodowych &bull; wardriving &amp; warchalking</title>\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../css/styles.css\">\n</head>\n<body>\n";
	echo "<form method=\"post\" action=\"?\">
        <div style=\"padding-top:1em;padding-bottom:0.5em\">password</div>
        <div><input type=\"password\" name=\"password\" size=\"26\" maxlength=\"50\"></div>
        <div style=\"padding-top:1em;padding-bottom:0.5em\">captcha</div>
        <div><input type=\"text\" name=\"captcha\" size=\"26\" maxlength=\"50\"></div>
        <div><br><img src=\"captcha.png\" alt=\"0\"></div>
        <div style=\"padding-top:1em\"><input type=\"submit\" name=\"submit\" value=\"submit\"></div>
        </form>\n";
	echo "</body>\n</html>";
        }

        if (!empty($_POST['captcha'])) {
        echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n<html>\n<head>\n    <meta http-equiv=\"Content-type\" content=\"text/html; charset=utf-8\">\n    <title>mapy sieci bezprzewodowych &bull; wardriving &amp; warchalking</title>\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../css/styles.css\">\n</head>\n<body>\n";
        echo "<div style=\"padding-top:1em;padding-bottom:0.5em;color:red;font-weight:bold\">Captcha verification failed. You may not be human. Please try again.</div>
	<form method=\"post\" action=\"?\">
        <div style=\"padding-top:1em;padding-bottom:0.5em\">password</div>
        <div><input type=\"password\" name=\"password\" size=\"26\" maxlength=\"50\"></div>
        <div style=\"padding-top:1em;padding-bottom:0.5em;color:red;font-weight:bold\">captcha</div>
        <div><input type=\"text\" name=\"captcha\" size=\"26\" maxlength=\"50\"></div>
        <div><br><img src=\"captcha.png\" alt=\"0\"></div>
        <div style=\"padding-top:1em\"><input type=\"submit\" name=\"submit\" value=\"submit\"></div>
        </form>\n";
        echo "</body>\n</html>";
	}

?>
