<?php
	// sprawdzenie czy zmienna istnieje
	if(!$pR2truDrAw) exit;
?>
   <p>Menu: <a href="mysql.php">mysql</a>, <a href="geocode.php">geocode</a>, <a href="staticmaps.php">staticmaps</a>.<br><a href="access.php?logout">&laquo;&nbsp;wyloguj</a></p>
   <p>Copyright &copy; 2010-2011 <a href="../contact.php" target="_blank">Adam Ziaja</a>. All Rights Reserved.</p>
</body>
</html>
