<?php
    $pR2truDrAw = true; // tajna zmienna potrzebna do zainkludowania plików
	require 'access.php';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Language" content="pl">
    <meta name="Author" content="Adam Ziaja">
    <meta name="Robots" content="NOINDEX, NOFOLLOW">
    <title>mapy sieci bezprzewodowych &bull; wardriving &amp; warchalking</title>
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
<?php
    require "../inc/connection.php";
    connection();

set_time_limit(0); // Maximum execution time of 30 seconds exceeded

$tiles=$_GET['tiles'];

define("MAP_TILES_CACHE_TIME", "60"); // 60 dni

if ($tiles=='google') {
  define("MAP_TILES_CACHE", "./cache/google/");
  $mapname='katowice-google';
} elseif ($tiles=='osm') {
  define("MAP_TILES_CACHE", "./cache/osm/");
  $mapname='katowice-osm';
} elseif ($tiles=='ump') {
  define("MAP_TILES_CACHE", "./cache/ump/");
  $mapname='katowice-ump';
} else {
    echo "<p>Wybierz warstw&#281;: <a href=\"?tiles=google\">Google</a>, <a href=\"?tiles=osm\">OpenStreetMap</a>, <a href=\"?tiles=ump\">UMP-pcPL</a>.</p>\n";
	include 'inc/dol.php';
	die;
}

	$zoom=15;

	$lat=dbquery("SELECT gpslat FROM wardriving WHERE admarea2 = 'Katowice' ORDER BY gpslat DESC LIMIT 1","gpslat");
	$gpslatmin=$lat;
	$lon=dbquery("SELECT gpslon FROM wardriving WHERE admarea2 = 'Katowice' ORDER BY gpslon DESC LIMIT 1","gpslon");
	$gpslonmax=$lon;
	$xtilemax = floor((($lon + 180) / 360) * pow(2, $zoom));
	$xtilemax=$xtilemax+1; // + tiles żeby było trochę poza granice
	$ytilemin = floor((1 - log(tan(deg2rad($lat)) + 1 / cos(deg2rad($lat))) / pi()) /2 * pow(2, $zoom));
	$ytilemin=$ytilemin-1; // + tiles żeby było trochę poza granice

	$lat=dbquery("SELECT gpslat FROM wardriving WHERE admarea2 = 'Katowice' ORDER BY gpslat ASC LIMIT 1","gpslat");
	$gpslatmax=$lat;
	$lon=dbquery("SELECT gpslon FROM wardriving WHERE admarea2 = 'Katowice' ORDER BY gpslon ASC LIMIT 1","gpslon");
	$gpslonmin=$lon;
	$xtilemin = floor((($lon + 180) / 360) * pow(2, $zoom));
	$xtilemin=$xtilemin-1; // + tiles żeby było trochę poza granice
	$ytilemax = floor((1 - log(tan(deg2rad($lat)) + 1 / cos(deg2rad($lat))) / pi()) /2 * pow(2, $zoom));
	$ytilemax=$ytilemax+1; // + tiles żeby było trochę poza granice

map($mapname,$xtilemin,$xtilemax,$ytilemin,$ytilemax,$zoom,10,$tiles);

function map($name, $xmin, $xmax, $ymin, $ymax, $zoom, $circle, $tiles)
{
		ob_implicit_flush();
		
		$error=0;
		$calcmax=log(tan(deg2rad(85.0511))+(1/cos(deg2rad(85.0511))));
		
		//echo $name."<br>\n";
		
		// Mapa składa się
		$xtiles=$xmax-$xmin+1;
		$ytiles=$ymax-$ymin+1;
		
		$map=imagecreatetruecolor($xtiles*256, $ytiles*256);

		echo "<p class=\"zielony\">Budowanie mapy...</p>";

		for($y=$ymin;$y<=$ymax;$y++)
		{
			for($x=$xmin;$x<=$xmax;$x++)
			{
				if($error==0)
				{
					$tile=map_gettile($x,$y,$zoom,$name);
					if(!$tile) $error=1;
					else
					{
						imagecopy($map,$tile,($x-$xmin)*256,($y-$ymin)*256,0,0,256,256);
						imagedestroy($tile);
					}
				}
			}
		}
		
		if($error==0)
		{
			$czcionka_georgia='/home/adam/wardriving.adamziaja.com/fonts/Georgia.ttf'; // duża/mała litera!
			$czcionka_verdana='/home/adam/wardriving.adamziaja.com/fonts/Verdana.ttf';
			$czcionka_arial='/home/adam/wardriving.adamziaja.com/fonts/Arial.ttf';

			$kolor_bialy=ImageColorAllocate($map,255,255,255);
			$kolor_czarny=ImageColorAllocate($map,0,0,0);
			$kolor_czerwony=ImageColorAllocate($map,255,0,0);
			$kolor_zielony=ImageColorAllocate($map,0,190,0);
			$kolor_niebieski=ImageColorAllocate($map,0,0,255);
			$kolor_szary=ImageColorAllocate($map,200,200,200);

			list($latmin,$latmax,$lonmin,$lonmax)=map_tiles_range($xmin,$xmax,$ymin,$ymax,$zoom);
			$zoomvalue=pow(2,$zoom);
			$calcmaxzoom=2*$calcmax/$zoomvalue;
			
			$xpixel=$xtiles*256;
			$ypixel=$ytiles*256;
			
			$aps=mysql_query("SELECT gpslat,gpslon,encryption1 FROM wardriving WHERE gpslon BETWEEN $lonmin AND $lonmax AND gpslat BETWEEN $latmin AND $latmax and gpslat!=0 and gpslon!=0");
			
			if($aps)
			{
				echo "\nSQL(".mysql_num_rows($aps).")";
				
				$num_aps=mysql_num_rows($aps)+0;
				$data=array();
				while($ap = mysql_fetch_array($aps))
				{
					if($ap['encryption1'] == "None") 
						$crypt=0;
					elseif($ap['encryption1'] == "WEP") 
						$crypt=1;
					else 
						$crypt=2;
					
					$xpos=(($ap[1] + 180) / 360)*$zoomvalue;
					$yrad=deg2rad($ap[0]);
					$ypos=($calcmax-log(tan($yrad)+(1/cos($yrad))))/$calcmaxzoom;
					
					$xpos=intval(256*($xpos-$xmin));
					$ypos=intval(256*($ypos-$ymin));
					
					if($crypt == 0) $farba=$kolor_zielony;
					elseif($crypt == 1) $farba=$kolor_niebieski;
					else $farba=$kolor_czerwony;
					
					if(@$position[$xpos][$ypos]!=1)
					{
						imagefilledarc($map, $xpos, $ypos, $circle-1, $circle-1, 0, 360, $farba, IMG_ARC_PIE); // kółeczko
						imagefilledarc($map, $xpos, $ypos, $circle, $circle, 0, 360, $kolor_czarny, IMG_ARC_NOFILL); // ramka kółeczka
						$position[$xpos][$ypos]=1;
					}
				}
				
				$picpath="../maps/".$name.".png";
				@unlink($picpath);
				$wapkce=dbquery("SELECT count(*) FROM wardriving WHERE admarea2 = 'Katowice'","count(*)");
				$data=date("d.m.Y");
				// cień:
				ImageTTFText($map,24,0,56,66,$kolor_czarny,$czcionka_georgia,"WARDRIVING & WARCHALKING @ Katowice, Poland");
				ImageTTFText($map,24,0,56,101,$kolor_czarny,$czcionka_georgia,"I found $wapkce ($data) Wireless Access Points in Katowice, Poland");
				ImageTTFText($map,24,0,56,136,$kolor_czarny,$czcionka_georgia,"This work by Adam Ziaja (http://adamziaja.com) is licensed under a Creative Commons Attribution-ShareAlike 2.0 License");
				ImageTTFText($map,24,0,56,171,$kolor_czarny,$czcionka_georgia,"OPEN node - green, WEP node - blue, WPA node - red");
				//
				ImageTTFText($map,24,0,55,65,$kolor_czerwony,$czcionka_georgia,"WARDRIVING & WARCHALKING @ Katowice, Poland");
				ImageTTFText($map,24,0,55,100,$kolor_czerwony,$czcionka_georgia,"I found $wapkce ($data) Wireless Access Points in Katowice, Poland");
				ImageTTFText($map,24,0,55,135,$kolor_czerwony,$czcionka_georgia,"This work by Adam Ziaja (http://adamziaja.com) is licensed under a Creative Commons Attribution-ShareAlike 2.0 License");
				ImageTTFText($map,24,0,55,170,$kolor_czerwony,$czcionka_georgia,"OPEN node - green, WEP node - blue, WPA node - red");
				//
				if ($tiles=='google') {
					ImageTTFText($map,24,0,56,206,$kolor_czarny,$czcionka_georgia,"Map tiles by Google (http://maps.google.com)");
					ImageTTFText($map,24,0,55,205,$kolor_czerwony,$czcionka_georgia,"Map tiles by Google (http://maps.google.com)");
				} elseif ($tiles=='osm') {
					ImageTTFText($map,24,0,56,206,$kolor_czarny,$czcionka_georgia,"Map tiles by OpenStreetMap (http://openstreetmap.org)");
					ImageTTFText($map,24,0,55,205,$kolor_czerwony,$czcionka_georgia,"Map tiles by OpenStreetMap (http://openstreetmap.org)");
				} elseif ($tiles=='ump') {
					ImageTTFText($map,24,0,56,206,$kolor_czarny,$czcionka_georgia,"Map tiles by UMP-pcPL (http://ump.waw.pl)");
					ImageTTFText($map,24,0,55,205,$kolor_czerwony,$czcionka_georgia,"Map tiles by UMP-pcPL (http://ump.waw.pl)");
				} else {
					die("Błąd");
				}
				//
				imagepng($map,$picpath);
				
				echo "\n<p class=\"zielony\">Mapa została utworzona: <a href='../maps/".$name.".png' target='_blank'>$name</a><br><a href=\"?\">&laquo;&nbsp;wróć</a></p>\n";
				
			}
		}
		else
		{
			echo "<p class=\"czerwony\">Wystąpił błąd.</p><a href=\"?\">&laquo;&nbsp;wróć</a>";
		}
		imagedestroy($map);
}

function map_tiles_range($xmin,$xmax,$ymin,$ymax,$zoom)
{
	$calcmax=log(tan(deg2rad(85.0511))+(1/cos(deg2rad(85.0511))));
	$zoomvalue=pow(2, $zoom);
	$calcmaxzoom=2*$calcmax/$zoomvalue;
	
	$lonmin= -180 + $xmin * (360 / $zoomvalue);
	$lonmax=(-180 + $xmax * (360 / $zoomvalue))+(360 / $zoomvalue);

	$latmin=rad2deg(atan(sinh(($calcmax)-(2*$calcmax)*(($ymax*(1/$zoomvalue))+(1/$zoomvalue)))));
	$latmax=rad2deg(atan(sinh((log(tan(deg2rad(85.0511)) + (1/cos(deg2rad(85.0511)))))
		- (2 * (log(tan(deg2rad(85.0511)) + (1/cos(deg2rad(85.0511))))))
		* ($ymin * (1 / $zoomvalue)))));
		
	return array($latmin,$latmax,$lonmin,$lonmax);
}

function map_gettile($x,$y,$zoom,$name)
{
	$path=MAP_TILES_CACHE.$zoom."-".$x."-".$y.".png";
	if(is_file($path)&&time()-filemtime($path)<MAP_TILES_CACHE_TIME*60*60*24) // "MAP_TILES_CACHE_TIME" dni przechowuje tiles w cache
	{
		echo "|";
	}
	else
	{
                if ($name=='katowice-google') {
                  $url="http://mt0.google.com/vt/lyrs=m&hl=pl&x=$x&y=$y&z=$zoom";
                } elseif ($name=='katowice-osm') {
                  $url="http://a.tile.openstreetmap.org/$zoom/$x/$y.png";
                } elseif ($name=='katowice-ump') {
                  $url="http://1.tiles.ump.waw.pl/ump_tiles/$zoom/$x/$y.png";
                } else { die ("Błąd, brak zdefiniowanego adresu URL!"); }
		@unlink($path);
                echo("*");
		shell_exec("wget -O$path '$url'");
		chmod ($path, 0777);
	}
	$tile=imagecreatefrompng($path);
	return $tile;
}

	include 'inc/dol.php';

?>
