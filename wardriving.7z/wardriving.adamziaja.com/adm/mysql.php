<?php
    $pR2truDrAw = true; // tajna zmienna potrzebna do zainkludowania plików
	require 'access.php';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Language" content="pl">
    <meta name="Author" content="Adam Ziaja">
    <meta name="Robots" content="NOINDEX, NOFOLLOW">
    <title>mapy sieci bezprzewodowych &bull; wardriving &amp; warchalking</title>
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
</head>
<body>
<?php
	require "../inc/connection.php";
	connection();

/*

CREATE TABLE wardriving ( 
id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
bssid char(17) NOT NULL UNIQUE, 
ssid char(32), 
cloaked char(5) NOT NULL, 
channel tinyint NOT NULL, 
encryption1 text NOT NULL, 
encryption2 text default NULL, 
encryption3 text default NULL, 
maxrate smallint NOT NULL, 
manuf text NOT NULL, 
gpslat double NOT NULL, 
gpslon double NOT NULL, 
signal tinyint default NULL, 
firstseen datetime NOT NULL, 
seen datetime NOT NULL, 
adddate datetime NOT NULL, 
changedate datetime NOT NULL, 
admarea3 text default NULL, 
admarea2 text default NULL, 
admarea1 text default NULL, 
address text default NULL
);

CREATE INDEX wardriving_bssid ON wardriving (bssid);

CREATE TABLE parser ( 
id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
logfile char(50) NOT NULL UNIQUE, 
adddate datetime NOT NULL 
);

CREATE TABLE log ( 
id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
ip varchar(15) NOT NULL, 
date datetime NOT NULL, 
error ENUM('n','y') NOT NULL, 
request text NOT NULL, 
string text NOT NULL 
);

http://dev.mysql.com/doc/refman/5.0/en/miscellaneous-functions.html#function_inet-aton
http://dev.mysql.com/doc/refman/5.0/en/miscellaneous-functions.html#function_inet-ntoa

CZYSZCZENIE:

TRUNCATE TABLE wardriving;
TRUNCATE TABLE parser;

*/

set_time_limit(0); // Maximum execution time of 30 seconds exceeded

$files = glob('./kismet/todo/Kismet-*.netxml');
if (!file_exists($kismetlog)) { echo "<p class=\"czerwony\">Brak logów do sparsowania! <a href=\"?\">Ponów próbę</a>.</p>\n"; }

foreach ($files as $kismetlog) {

if (file_exists($kismetlog)) { // tylko jeżli plik istnieje
$xml=simplexml_load_file($kismetlog); // ładowanie pliku

echo "<p class=\"zielony\">Ładuję ".$kismetlog." do bazy danych.</p>";

foreach ($xml->{'wireless-network'} as $wirelessnetwork){ // dla każdej znalezionej sieci
	if($wirelessnetwork['type']=='infrastructure'){ // tylko jeśli typ sieci to infrastruktura
	if($wirelessnetwork->{'gps-info'}->{'avg-lat'}!=0&&$wirelessnetwork->{'gps-info'}->{'avg-lon'}!=0&&$wirelessnetwork->SSID->encryption[0]!=''&&$wirelessnetwork->channel!=0){
	$query="SELECT * FROM wardriving WHERE bssid = '".$wirelessnetwork->BSSID."'";
    $result=mysql_query($query);
    $num=mysql_num_rows($result);
	if($num==0) {
		$seen=$wirelessnetwork['last-time'];

			//if ($wirelessnetwork->manuf=='Unknown') {
			$mac=$wirelessnetwork->BSSID;
			list($mac1, $mac2, $mac3)=explode(":", $mac);
			$mac24="$mac1:$mac2:$mac3";
			$query="SELECT * FROM manuf WHERE mac='".$mac24."'";
			$result=mysql_query($query);
			$num=mysql_num_rows($result);
			if($num>0) {
				$manuf=mysql_result($result,$i,"manuf");
			}
			//} else {$manuf=$wirelessnetwork->manuf;}

		mysql_query("INSERT INTO wardriving (bssid,ssid,cloaked,channel,encryption1,encryption2,encryption3,maxrate,manuf,gpslat,gpslon,signal,firstseen,seen,adddate,changedate) VALUES('"
		.$wirelessnetwork->BSSID."','"
		.addslashes($wirelessnetwork->SSID->essid)."','" // problem występuje ze znakami jak '
		.$wirelessnetwork->SSID->essid['cloaked']."','"
        .$wirelessnetwork->channel."','"
		.$wirelessnetwork->SSID->encryption[0]."','"
		.$wirelessnetwork->SSID->encryption[1]."','"
		.$wirelessnetwork->SSID->encryption[2]."','"
		.round($wirelessnetwork->SSID->{'max-rate'},0)."','" // ucina zera
        .$manuf."','" // z własnej bazy
		.$wirelessnetwork->{'gps-info'}->{'avg-lat'}."','"
		.$wirelessnetwork->{'gps-info'}->{'avg-lon'}."','"
		.$wirelessnetwork->{'snr-info'}->{'max_signal_dbm'}."','"
		.date('Y-m-d H:i:s', strtotime("$seen"))."','" // pierwszy raz widziana
		.date('Y-m-d H:i:s', strtotime("$seen"))."','" // ostatnio widziana
		.date('Y-m-d H:i:s')."','" // data dodania do bazy
		.date('Y-m-d H:i:s')."');"); // data aktualizacji w bazie
		//or die('Błąd zapytania do bazy danych.')
	}
    if($num==1) {

		$seen=$wirelessnetwork['last-time']; // update kiedy ostatni raz widziana
			mysql_query("UPDATE wardriving SET seen='".date('Y-m-d H:i:s', strtotime("$seen"))."' WHERE bssid='".$wirelessnetwork->BSSID."';");

		$signal=dbquery("SELECT signal FROM wardriving WHERE bssid='".$wirelessnetwork->BSSID."'","signal");
		if($signal='0'||$signal<$wirelessnetwork->{'snr-info'}->{'max_signal_dbm'}){ // jeśli lepszy sygnał
			mysql_query("UPDATE wardriving SET gpslat='".$wirelessnetwork->{'gps-info'}->{'avg-lat'}.
			"',gpslon='".$wirelessnetwork->{'gps-info'}->{'avg-lon'}.
			"',signal='".$wirelessnetwork->{'snr-info'}->{'max_signal_dbm'}.
			"',changedate='".date('Y-m-d H:i:s').
			"',admarea3=NULL,admarea2=NULL,admarea1=NULL,address=NULL WHERE bssid='".$wirelessnetwork->BSSID."';");
		}

		$ssid=dbquery("SELECT ssid FROM wardriving WHERE bssid='".$wirelessnetwork->BSSID."'","ssid");
		if($ssid!=(addslashes($wirelessnetwork->SSID->essid))){ // jeśli inny SSID
			mysql_query("UPDATE wardriving SET ssid='".addslashes($wirelessnetwork->SSID->essid).
			"',changedate='".date('Y-m-d H:i:s').
			"' WHERE bssid='".$wirelessnetwork->BSSID."';");
		}

		$cloaked=dbquery("SELECT cloaked FROM wardriving WHERE bssid='".$wirelessnetwork->BSSID."'","cloaked");
		if($cloaked!=$wirelessnetwork->SSID->essid['cloaked']){ // widoczność
			mysql_query("UPDATE wardriving SET cloaked='".$wirelessnetwork->SSID->essid['cloaked'].
			"',changedate='".date('Y-m-d H:i:s').
			"' WHERE bssid='".$wirelessnetwork->BSSID."';");
		}

		$channel=dbquery("SELECT channel FROM wardriving WHERE bssid='".$wirelessnetwork->BSSID."'","channel");
		if($channel!=$wirelessnetwork->channel){ // jeśli inny kanał
			mysql_query("UPDATE wardriving SET channel='".$wirelessnetwork->channel.
			"',changedate='".date('Y-m-d H:i:s').
			"' WHERE bssid='".$wirelessnetwork->BSSID."';");
		}

		mysql_query("UPDATE wardriving SET encryption1='".$wirelessnetwork->SSID->encryption[0].
			"',changedate='".date('Y-m-d H:i:s').
			"' WHERE bssid='".$wirelessnetwork->BSSID."';"); // nadpisuje szyfrowanie bo może być inna kolejność

		mysql_query("UPDATE wardriving SET encryption2='".$wirelessnetwork->SSID->encryption[1].
			"',changedate='".date('Y-m-d H:i:s').
			"' WHERE bssid='".$wirelessnetwork->BSSID."';"); // nadpisuje szyfrowanie bo może być inna kolejność

		mysql_query("UPDATE wardriving SET encryption3='".$wirelessnetwork->SSID->encryption[2].
			"',changedate='".date('Y-m-d H:i:s').
			"' WHERE bssid='".$wirelessnetwork->BSSID."';"); // nadpisuje szyfrowanie bo może być inna kolejność

		$maxrate=dbquery("SELECT maxrate FROM wardriving WHERE bssid='".$wirelessnetwork->BSSID."'","maxrate");
		if($maxrate!=(round($wirelessnetwork->SSID->{'max-rate'},0))){ // jeśli inna prędkość
			mysql_query("UPDATE wardriving SET maxrate='".round($wirelessnetwork->SSID->{'max-rate'},0).
			"',changedate='".date('Y-m-d H:i:s').
			"' WHERE bssid='".$wirelessnetwork->BSSID."';");
	}

	}
	}
	}
}

rename("$kismetlog", "./kismet/done/".basename($kismetlog)); // przenosi z /todo/ do /done/ po ukończeniu

} else {
    exit('Nie mogę otworzyć '."$kismetlog".'.'); // jeśli plik nie istnieje
}

	mysql_query("INSERT INTO parser (logfile,adddate) VALUES('".basename($kismetlog)."','".date('Y-m-d H:i:s')."');");	// data dodania do bazy

}

	include 'inc/dol.php';

?>
