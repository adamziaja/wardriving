<?php
    $pR2truDrAw = true;     // tajna zmienna potrzebna do zainkludowania plików
    include 'inc/gora.php';

    $zebra=0;

    $bssid=mysql_real_escape_string(htmlspecialchars(addslashes($_GET['bssid']),ENT_QUOTES));  // zabezpieczenie przeciw mysql injection
    if (!preg_match("@[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}@",$bssid)) {
        echo "<div style=\"text-align:center;\" class=\"czerwony\">Błąd! Podany adres BSSID (MAC) nie jest prawidłowy.</div>";
        include 'inc/dol.php';
        die;
    }

    $query="SELECT * FROM wardriving WHERE bssid = '".$bssid."' LIMIT 1";   // na wszelki wypadek LIMIT 1 mimo ze powinien byc unikalny
    $result=mysql_query($query);
    $num=mysql_num_rows($result);

    if($num>0) {

		$query="INSERT INTO log (ip,date,error,request,string) VALUES('".$_SERVER['REMOTE_ADDR']."','".date('Y-m-d H:i:s')."','n','".addslashes($_SERVER['REQUEST_URI'])."','".addslashes($_GET['bssid'])."')";
		mysql_query($query);

        $bssid=mysql_result($result,$i,"bssid");

        $ssid=htmlspecialchars(mysql_result($result,$i,"ssid"),ENT_QUOTES);

        $cloaked=mysql_result($result,$i,"cloaked");
            if($cloaked=="true") {$cloaked="<span class=\"szary\">nazwa sieci została ukryta</span>";}
            if($cloaked=="false") {$cloaked="";}

        $channel=mysql_result($result,$i,"channel");
            if($channel=="0") {$channel="<span class=\"szary\">?</span>";}

        if ($channel==1) {$frequency=" (2,412 GHz)";}
        if ($channel==2) {$frequency=" (2,417 GHz)";}
        if ($channel==3) {$frequency=" (2,422 GHz)";}
        if ($channel==4) {$frequency=" (2,427 GHz)";}
        if ($channel==5) {$frequency=" (2,432 GHz)";}
        if ($channel==6) {$frequency=" (2,437 GHz)";}
        if ($channel==7) {$frequency=" (2,442 GHz)";}
        if ($channel==8) {$frequency=" (2,447 GHz)";}
        if ($channel==9) {$frequency=" (2,452 GHz)";}
        if ($channel==10) {$frequency=" (2,457 GHz)";}
        if ($channel==11) {$frequency=" (2,462 GHz)";}
        if ($channel==12) {$frequency=" (2,467 GHz)";}
        if ($channel==13) {$frequency=" (2,472 GHz)";}
        if ($channel==14) {$frequency=" <span class=\"czerwony\">(2,484 GHz) W Polsce tylko częstotliwości od 2,4000 do <b>2,4835 GHz</b> nie wymagają koncesji!</span>";}

        $encryption1=mysql_result($result,$i,"encryption1");
        $encryption2=mysql_result($result,$i,"encryption2");
        $encryption3=mysql_result($result,$i,"encryption3");
            if($encryption1=="None") {$encryption1="<span class=\"zielony\">brak szyfrowania</span>";}
            if(substr($encryption1,0,3)=="WEP") {$encryption1="<span class=\"niebieski\">".$encryption1."</span>";}
            if(substr($encryption1,0,3)=="WPA") {if($encryption1!="") {$encryption1="<span class=\"czerwony\">".$encryption1."</span>";}}
            if(substr($encryption2,0,3)=="WPA") {if($encryption2!="") {$encryption2="<span class=\"czerwony\">".$encryption2."</span>";}}
            if(substr($encryption3,0,3)=="WPA") {if($encryption3!="") {$encryption3="<span class=\"czerwony\">".$encryption3."</span>";}}
        if($encryption2!="") {$encryption2=", ".$encryption2."";}
        if($encryption3!="") {$encryption3=", ".$encryption3."";}
        $encryption=($encryption1.$encryption2.$encryption3);

        $maxrate=mysql_result($result,$i,"maxrate");

        $manuf=htmlspecialchars(mysql_result($result,$i,"manuf"));
            if($manuf=="Unknown") {$manuf="<span class=\"szary\">nieznany</span>";}

        $gpslat=mysql_result($result,$i,"gpslat");
        $gpslon=mysql_result($result,$i,"gpslon");
        $gpslatDECtoDMS=DECtoDMS($gpslat);
        $gpslonDECtoDMS=DECtoDMS($gpslon);
        $gps=($gpslat.",".$gpslon);
        $gpsDECtoDMS=($gpslatDECtoDMS.",".$gpslonDECtoDMS);

        $firstseen=mysql_result($result,$i,"firstseen");

        $seen=mysql_result($result,$i,"seen");

        $adddate=mysql_result($result,$i,"adddate");

        $changedate=mysql_result($result,$i,"changedate");

        $address=mysql_result($result,$i,"address");
          if (empty($address)) {$address="<span class=\"szary\">brak danych</span>";}

        $signal=mysql_result($result,$i,"signal");
          if (empty($signal)) {$signal="<span class=\"szary\">?</span>";}

            echo "<table class=\"ap\" border=\"0\" cellpadding=\"5\" cellspacing=\"1\" width=\"100%\">\n";

            echo "<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th width=\"220\">SSID (nazwa sieci)</th><td>$ssid$cloaked</td></tr>
<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th>BSSID (adres MAC urządzenia)</th><td>$bssid</td></tr>
<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th>Producent urządzenia</th><td>$manuf</td></tr>
<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th>Kanał</th><td>$channel$frequency</td></tr>
<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th>Prędkość sieci</th><td>$maxrate Mb/s</td></tr>
<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th>Sposób szyfrowania</th><td>$encryption</td></tr>
<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th>Sygnał</th><td>$signal dBm</td></tr>
<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th>Pozycja GPS</th><td><a href=\"http://maps.google.pl/maps?q=$gps\" target=\"_blank\">$gpsDECtoDMS ($gps)</a></td></tr>
<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th>Adres</th><td>$address</td></tr>
<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th>Pierwszy raz widziana</th><td>$firstseen</td></tr>
<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th>Ostatni raz widziana</th><td>$seen</td></tr>
<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th>Dodana do bazy</th><td>$adddate</td></tr>
<tr class=\"".($zebra++&1 ? 'zebra2' : 'zebra1')."\"><th>Aktualizowana w bazie</th><td>$changedate</td></tr>\n";

            echo "</table>\n";

            echo "<br><div style=\"float:left\"><a href=\"maps.php?lat=$gpslat&amp;lon=$gpslon&amp;zoom=16\" target=\"_blank\"><img src=\"http://maps.google.com/maps/api/staticmap?zoom=15&amp;size=486x400&amp;markers=icon:http://img408.imageshack.us/img408/679/wifi.png|$gps&amp;sensor=false\" class=\"mapastatyczna\" alt=\"$gpsDECtoDMS\"></a></div>&nbsp;<a href=\"maps.php?lat=$gpslat&amp;lon=$gpslon&amp;zoom=16\" target=\"_blank\"><img src=\"http://maps.google.com/maps/api/staticmap?zoom=13&amp;size=486x400&amp;markers=icon:http://img408.imageshack.us/img408/679/wifi.png|$gps&amp;sensor=false\" class=\"mapastatyczna\" alt=\"$gpsDECtoDMS\"></a>";

    }
    else {
		// logowanie błędu
		$query="INSERT INTO log (ip,date,error,request,string) VALUES('".$_SERVER['REMOTE_ADDR']."','".date('Y-m-d H:i:s')."','y','".addslashes($_SERVER['REQUEST_URI'])."','".addslashes($_GET['bssid'])."')";
		mysql_query($query);
        echo "<div style=\"text-align:center;\" class=\"czerwony\">Błąd! Podany adres BSSID (MAC) nie istnieje w bazie.</div>";
    }

include 'inc/dol.php';

?>
