<?php echo '<?xml version="1.0" encoding="iso-8859-1"?>'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="EN">
	<head>
	<style>
		body {
			border: 0px;
			margin: 0px;
			padding: 0px;
			height: 100%;
			color: #000;
			font-size: 75%;
			font-family: Verdana, Arial, Helvetica, sans-serif;
		}
		#map {
			width: 100%;
			height: 100%;
			border: 0px;
			padding: 0px;
			position: absolute;
	    }
		div.olControlAttribution {text-align:right;}
	</style>
	<script src='http://www.openlayers.org/api/OpenLayers.js'></script>
	<script src='http://www.openstreetmap.org/openlayers/OpenStreetMap.js'></script>
	<script type="text/javascript">
		function changeQuery()
		{
				inputEle = document.getElementById('amenity');
				radiusInput = document.getElementById('radius');
				center = map.getCenter().transform(map.getProjectionObject(), new OpenLayers.Projection("EPSG:4326"));
				pois.destroy();
				pois = new OpenLayers.Layer.Text( "Wireless Access Point",
						{
						  location:"./fetch.php?lat=" + center.lat + '&lon=' + center.lon,
						  projection: map.displayProjection
						});
				map.addLayer(pois);

            multiFeature = new OpenLayers.Feature.Vector(
                    OpenLayers.Geometry.Polygon.createRegularPolygon(
                        new OpenLayers.Geometry.Point(center.lon,center.lat).transform(new OpenLayers.Projection("EPSG:4326"), map.getProjectionObject()),
						1.08 * 1000 / Math.cos(center.lat / (180/Math.PI)), 10 + map.getZoom() * 2, 10 // 1.08km
                ),
                {
                    color: 'blue',
                    align: 'rt'
                });

			vectorLayer.removeAllFeatures();
			vectorLayer.drawFeature(multiFeature);
			vectorLayer.addFeatures([multiFeature]);
		}

		function moveEndEvent(event)
		{
			changeQuery();
		}

		var lat=<?php $lat=htmlspecialchars($_GET['lat']); if (!empty($lat)) {echo $lat."\n";} else {echo "50.25\n";} ?>
		var lon=<?php $lon=htmlspecialchars($_GET['lon']); if (!empty($lon)) {echo $lon."\n";} else {echo "19\n";} ?>
		var zoom=<?php $zoom=htmlspecialchars($_GET['zoom']); if (!empty($zoom)) {echo $zoom."\n";} else {echo "14\n";} ?>

		var map;

		function init() {
			map = new OpenLayers.Map ("map", {
				eventListeners: {
					"moveend": moveEndEvent
				},
				controls:[
					new OpenLayers.Control.Navigation(),
					new OpenLayers.Control.PanZoomBar(),
					new OpenLayers.Control.LayerSwitcher(),
					//new OpenLayers.Control.Permalink(),
					new OpenLayers.Control.ScaleLine(),
					new OpenLayers.Control.MousePosition(),
                    //new OpenLayers.Control.OverviewMap(),
					new OpenLayers.Control.Attribution()],
				maxExtent: new OpenLayers.Bounds(-20037508.34,-20037508.34,20037508.34,20037508.34),
				maxResolution: 156543.0399,
				numZoomLevels: 19,
				units: 'mi',
				projection: new OpenLayers.Projection("EPSG:900913"),
				displayProjection: new OpenLayers.Projection("EPSG:4326")
			} );

			var layerUMP = new OpenLayers.Layer.OSM("UMP-pcPL",
                [
				 "http://1.tiles.ump.waw.pl/ump_tiles/${z}/${x}/${y}.png",
				 "http://2.tiles.ump.waw.pl/ump_tiles/${z}/${x}/${y}.png",
				 "http://3.tiles.ump.waw.pl/ump_tiles/${z}/${x}/${y}.png"
				],
                {numZoomLevels: 19, 'buffer':0, transitionEffect: 'resize',
                attribution: "Copyright &copy; <b><a href='contact.php'>Adam Ziaja</a></b><br>Map tiles &copy; <a href='http://ump.waw.pl'>UMP-pcPL</a>"}
			);
			var layerMapnik = new OpenLayers.Layer.OSM.Mapnik("OSM Mapnik",
				{attribution: "Copyright &copy; <b><a href='contact.php'>Adam Ziaja</a></b><br>Map tiles &copy; <a href='http://openstreetmap.org'>OpenStreetMap</a>"}
			);
			var layerOsmarender = new OpenLayers.Layer.OSM.Osmarender("OSM Osmarender",
				{attribution: "Copyright &copy; <b><a href='contact.php'>Adam Ziaja</a></b><br>Map tiles &copy; <a href='http://openstreetmap.org'>OpenStreetMap</a>"}
			);
			var layerOPNV = new OpenLayers.Layer.OSM("&Ouml;PNV-Karte",
				"http://tile.xn--pnvkarte-m4a.de/tilegen/${z}/${x}/${y}.png",
				{numZoomLevels: 19, 'buffer':0,
                attribution: "Copyright &copy; <b><a href='contact.php'>Adam Ziaja</a></b><br>Map tiles &copy; <a href='http://xn--pnvkarte-m4a.de'>&Ouml;PNV-Karte</a>"}
			);
			var layerGoogleStreets = new OpenLayers.Layer.OSM("Google Mapa",
                [
				 "http://mt0.google.com/vt/lyrs=m&hl=pl&x=${x}&y=${y}&z=${z}",
				 "http://mt1.google.com/vt/lyrs=m&hl=pl&x=${x}&y=${y}&z=${z}"
				],
                {numZoomLevels: 20,
                attribution: "Copyright &copy; <b><a href='contact.php'>Adam Ziaja</a></b><br>Map tiles &copy; <a href='http://maps.google.com'>Google</a>"}
            );
			var layerGoogleTerrain = new OpenLayers.Layer.OSM("Google Teren",
                [
				 "http://mt0.google.com/vt/lyrs=p&hl=pl&x=${x}&y=${y}&z=${z}",
				 "http://mt1.google.com/vt/lyrs=p&hl=pl&x=${x}&y=${y}&z=${z}"
				],
                {numZoomLevels: 20,
                attribution: "Copyright &copy; <b><a href='contact.php'>Adam Ziaja</a></b><br>Map tiles &copy; <a href='http://maps.google.com'>Google</a>"}
            );
			var layerGoogleAerial = new OpenLayers.Layer.OSM("Google Satelita",
                [
				 "http://mt0.google.com/vt/lyrs=y&hl=pl&x=${x}&y=${y}&z=${z}",
				 "http://mt1.google.com/vt/lyrs=y&hl=pl&x=${x}&y=${y}&z=${z}"
				],
                {numZoomLevels: 20,
                attribution: "Copyright &copy; <b><a href='contact.php'>Adam Ziaja</a></b><br>Map tiles &copy; <a href='http://maps.google.com'>Google</a>"}
            );

	    var layerOviStreets = new OpenLayers.Layer.OSM("Ovi Mapa", ["http://a.maptile.maps.svc.ovi.com/maptiler/maptile/newest/normal.day/${z}/${x}/${y}/256/png8",
                                                "http://b.maptile.maps.svc.ovi.com/maptiler/maptile/newest/normal.day/${z}/${x}/${y}/256/png8"], {
                transitionEffect: 'resize', sphericalMercator: true, numZoomLevels: 21,
		attribution: "Copyright &copy; <b><a href='contact.php'>Adam Ziaja</a></b><br>Map tiles &copy; <a href='http://maps.ovi.com'>Ovi Maps</a>"
            });
            var layerOviTransit = new OpenLayers.Layer.OSM("Ovi Tranzyt", ["http://c.maptile.maps.svc.ovi.com/maptiler/maptile/newest/normal.day.transit/${z}/${x}/${y}/256/png8",
                                                "http://d.maptile.maps.svc.ovi.com/maptiler/maptile/newest/normal.day.transit/${z}/${x}/${y}/256/png8"], {
                transitionEffect: 'resize', sphericalMercator: true, numZoomLevels: 21,
		attribution: "Copyright &copy; <b><a href='contact.php'>Adam Ziaja</a></b><br>Map tiles &copy; <a href='http://maps.ovi.com'>Ovi Maps</a>"
            });
            var layerOviSatellite = new OpenLayers.Layer.OSM("Ovi Satelita", ["http://e.maptile.maps.svc.ovi.com/maptiler/maptile/newest/hybrid.day/${z}/${x}/${y}/256/png8",
                                                   "http://f.maptile.maps.svc.ovi.com/maptiler/maptile/newest/hybrid.day/${z}/${x}/${y}/256/png8"],
                {
                transitionEffect: 'resize', sphericalMercator: true, numZoomLevels: 21,
		attribution: "Copyright &copy; <b><a href='contact.php'>Adam Ziaja</a></b><br>Map tiles &copy; <a href='http://maps.ovi.com'>Ovi Maps</a>"
            });

			map.addLayers([layerGoogleStreets,layerGoogleTerrain,layerGoogleAerial,layerOviStreets,layerOviTransit,layerOviSatellite,layerMapnik,layerOsmarender,layerUMP,layerOPNV]);

			vectorLayer = new OpenLayers.Layer.Vector("Area",
			{
                styleMap: new OpenLayers.StyleMap({'default':{
                    strokeColor: "${color}",
                    strokeOpacity: 1,
                    strokeWidth: 1,
                    fillColor: "${color}",
                    fillOpacity: 0.1,
                    pointRadius: 6,
                    pointerEvents: "visiblePainted",
                    fontColor: "${favColor}",
                    fontSize: "18px",
                    fontFamily: "Arial",
                    labelAlign: "${align}",
                    labelXOffset: "${xOffset}",
                    labelYOffset: "${yOffset}"
                }})
            });

            multiFeature = new OpenLayers.Feature.Vector(
                    new OpenLayers.Geometry.LinearRing([
                        new OpenLayers.Geometry.Point(-0.489,51.28).transform(new OpenLayers.Projection("EPSG:4326"), map.getProjectionObject()),
                        new OpenLayers.Geometry.Point(-0.489,51.68).transform(new OpenLayers.Projection("EPSG:4326"), map.getProjectionObject()),
                        new OpenLayers.Geometry.Point(0.236,51.68).transform(new OpenLayers.Projection("EPSG:4326"), map.getProjectionObject()),
                        new OpenLayers.Geometry.Point(0.236,51.28).transform(new OpenLayers.Projection("EPSG:4326"), map.getProjectionObject()),
                        new OpenLayers.Geometry.Point(-0.489,51.28).transform(new OpenLayers.Projection("EPSG:4326"), map.getProjectionObject())
                ]),
                {
                    color: 'black',
                    align: 'rt'
                });

			map.addLayer(vectorLayer);
            vectorLayer.drawFeature(multiFeature);
			vectorLayer.addFeatures([multiFeature]);

            pois = new OpenLayers.Layer.Text( "Wireless Access Point",
                    { location:"./fetch.php?lat=50.25&lon=19.00",
                      projection: map.displayProjection
                    });
            map.addLayer(pois);

			var lonLat = new OpenLayers.LonLat(lon, lat).transform(map.displayProjection, map.projection);
			map.setCenter(lonLat, zoom);
		}
	</script>
	<title>mapy sieci bezprzewodowych &bull; wardriving &amp; warchalking</title>
</head>
<body onload="init();">
<div id='map'></div>
<!-- stat - początek -->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-21262994-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<!-- stat - koniec -->
</body>
</html>
