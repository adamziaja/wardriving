<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Language" content="pl">
    <meta name="Keywords" content="mapy sieci bezprzewodowych, wardriving, warchalking, warxing, wireless, wifi">
    <meta name="Description" content="wardriving, warchalking">
    <meta name="Author" content="Adam Ziaja">
    <meta name="Robots" content="INDEX, FOLLOW">
    <title>mapy sieci bezprzewodowych &bull; wardriving &amp; warchalking</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <div id="blok">
    <!-- blok - początek -->
        <div id="pietro1" class="pietro1"><a href="index.php">mapy sieci bezprzewodowych</a></div>
        <div id="pietro2mieszkanie1" class="pietro2mieszkanie1">baza zawiera dane <b>13428</b> sieci bezprzewodowych</div>
        <div id="pietro2mieszkanie2" class="pietro2mieszkanie2">ostatnia aktualizacja bazy <b>2011-02-27</b> <a href="rss.php"><img src="img/rss.png" width="14" height="14" alt="RSS" style="vertical-align:top;border:0;"></a></div>
        <div id="pietro3" class="pietro3">
            <div class="menu">
                <ul>
                    <li><a href="/">strona główna</a></li><li><a href="maps.php" target="_blank">interaktywne mapy sieci</a></li><li><a href="staticmaps.php">statyczne mapy sieci</a></li><li><a href="db.php">baza sieci</a></li><li><a href="search.php">wyszukiwarka sieci</a></li><li><a href="stats.php">statystyki sieci</a></li><li><a href="contact.php">kontakt</a></li><!-- <li><a href="links.php">odnośniki</a></li> -->
                </ul>
            </div>
        </div>
<div id="pietro4" class="pietro4">
<!-- środek - początek -->
Ilość znalezionych sieci:&nbsp;13428<br><br>
Ilość sieci bez szyfrowania:&nbsp;1580 (11.766%)<br>
Ilość sieci z szyfrowaniem WEP:&nbsp;3746 (27.897%)<br>
<span class="szary">-- szyfrowanie złamane</span><br>
Ilość sieci z szyfrowaniem WPA:&nbsp;8102 (60.337%)<br>
<span class="szary">-- szyfrowanie WPA1 złamane, WPA2 dotychczas nie złamane</span><br><br>
Ilość sieci WPA Personal (PSK):&nbsp;8023 (99.02% WPA)<br>
<span class="szary">-- klienci współdzielą klucz</span><br>
Ilość sieci WPA Enterprise (RADIUS):&nbsp;79 (0.98% WPA)<br>
<span class="szary">-- każdy klient otrzymuje własny klucz</span><br><br>
Ilość sieci WPA1 TKIP:&nbsp;6573<br>
Ilość sieci WPA2 AES:&nbsp;5362<br>
<span class="szary">-- większość AP udostępnia oba (WPA1/WPA2) sposoby szyfrowania jednocześnie</span><br><br>
Ilość sieci wyłącznie z szyfrowaniem WPA2 AES:&nbsp;1533 (11.42%)<br>
<span class="szary">-- jedyny bezpieczny sposób szyfrowania</span><br>
Ilość względnie słabo zabezpieczonych sieci:&nbsp;11895 (88.58%)<br>
<br>Miasta wg ilości występowania:<br>1. Katowice - 11875 (88.43%)<br>
2. Chorzów - 935 (6.96%)<br>
3. Mikołów - 218 (1.62%)<br>
4. Ruda Śląska - 205 (1.53%)<br>
5. Zabrze - 130 (0.97%)<br>
6. Sosnowiec - 33 (0.25%)<br>
7. Czeladź - 22 (0.16%)<br>
8. Świętochłowice - 7 (0.05%)<br>
9. Łaziska Górne - 2 (0.01%)<br>
10. Będzin - 1 (0.01%)<br>
<br>Powiaty wg ilości występowania:<br>1. Katowice - 11875 (88.43%)<br>
2. Chorzów - 935 (6.96%)<br>
3. Mikołowski - 220 (1.64%)<br>
4. Ruda Śląska - 205 (1.53%)<br>
5. Zabrze - 130 (0.97%)<br>
6. Sosnowiec - 33 (0.25%)<br>
7. Będziński - 23 (0.17%)<br>
8. Świętochłowice - 7 (0.05%)<br>
<br>Województwa wg ilości występowania:<br>1. Śląskie - 13428 (100%)<br>
<br>Kanały wg ilości występowania:<br>1. Kanał 6 - 3811 (28.381%)<br>
2. Kanał 11 - 3398 (25.305%)<br>
3. Kanał 1 - 2264 (16.86%)<br>
4. Kanał 10 - 1805 (13.442%)<br>
5. Kanał 2 - 402 (2.994%)<br>
6. Kanał 3 - 311 (2.316%)<br>
7. Kanał 9 - 288 (2.145%)<br>
8. Kanał 7 - 270 (2.011%)<br>
9. Kanał 4 - 251 (1.869%)<br>
10. Kanał 8 - 242 (1.802%)<br>
11. Kanał 5 - 198 (1.475%)<br>
12. Kanał 13 - 99 (0.737%)<br>
13. Kanał 12 - 80 (0.596%)<br>
14. Kanał 14 - 9 (0.067%)<br>
<br>Prędkość:<br>1. 54 Mb/s - 12749 (94.943%)<br>
2. 11 Mb/s - 577 (4.297%)<br>
3. 22 Mb/s - 28 (0.209%)<br>
4. 9 Mb/s - 16 (0.119%)<br>
5. 2 Mb/s - 11 (0.082%)<br>
6. 18 Mb/s - 10 (0.074%)<br>
7. 6 Mb/s - 9 (0.067%)<br>
8. 36 Mb/s - 8 (0.06%)<br>
9. 5 Mb/s - 7 (0.052%)<br>
10. 12 Mb/s - 5 (0.037%)<br>
11. 24 Mb/s - 4 (0.03%)<br>
12. 1 Mb/s - 2 (0.015%)<br>
13. 48 Mb/s - 1 (0.007%)<br>
<br>Dziesięć najczęściej występujących SSID:<br>1. NETGEAR - 443 (3.299%)<br>
2. linksys - 351 (2.614%)<br>
3. dlink - 320 (2.383%)<br>
4. Dom - 173 (1.288%)<br>
5. Default - 155 (1.154%)<br>
6. TP-LINK - 108 (0.804%)<br>
7. Domek - 57 (0.424%)<br>
8. airlive - 43 (0.32%)<br>
9. GIGABYTE - 42 (0.313%)<br>
10. belkin54g - 31 (0.231%)<br>
<br>Dziesięć najczęściej występujących producentów:<br>1. Netgear - 1820 (13.554%)<br>
2. D-Link - 1705 (12.697%)<br>
3. Cisco-Li - 1619 (12.057%)<br>
4. Usi - 1590 (11.841%)<br>
5. Tp-LinkT - 1473 (10.97%)<br>
6. Thomson - 886 (6.598%)<br>
7. EdimaxTe - 430 (3.202%)<br>
8. HuaweiTe - 398 (2.964%)<br>
9. PlanetTe - 283 (2.108%)<br>
10. AsustekC - 259 (1.929%)<br>
<br>Ilość Neostrad ze standardowym SSID:&nbsp;1502<br>
Ilość Neostrad bez szyfrowania:&nbsp;39 (2.597%)<br>
Ilość Neostrad z szyfrowaniem WEP:&nbsp;1388 (92.41%)<br>
Ilość Neostrad z szyfrowaniem WPA:&nbsp;75 (4.993%)<br>
Ilość Neostrad występujących na poszczególnych kanałach:<br>1. Kanał 10 - 1444 (96.138%)<br>
2. Kanał 3 - 9 (0.599%)<br>
3. Kanał 6 - 8 (0.533%)<br>
4. Kanał 1 - 8 (0.533%)<br>
5. Kanał 11 - 7 (0.466%)<br>
6. Kanał 7 - 7 (0.466%)<br>
7. Kanał 5 - 6 (0.399%)<br>
8. Kanał 2 - 4 (0.266%)<br>
9. Kanał 8 - 4 (0.266%)<br>
10. Kanał 9 - 2 (0.133%)<br>
11. Kanał 4 - 2 (0.133%)<br>
12. Kanał 12 - 1 (0.067%)<br>
<br>Ilość Netii ze standardowym SSID:&nbsp;226<br>
Ilość Netii bez szyfrowania:&nbsp;5 (2.212%)<br>
Ilość Netii z szyfrowaniem WEP:&nbsp;0 (0%)<br>
Ilość Netii z szyfrowaniem WPA:&nbsp;221 (97.788%)<br>
Ilość Netii występujących na poszczególnych kanałach:<br>1. Kanał 11 - 118 (52.212%)<br>
2. Kanał 1 - 68 (30.088%)<br>
3. Kanał 6 - 38 (16.814%)<br>
4. Kanał 8 - 1 (0.442%)<br>
5. Kanał 5 - 1 (0.442%)<br>
<br>Ilość UPC ze standardowym SSID:&nbsp;814<br>
Ilość UPC bez szyfrowania:&nbsp;2 (0.246%)<br>
Ilość UPC z szyfrowaniem WEP:&nbsp;8 (0.983%)<br>
Ilość UPC z szyfrowaniem WPA:&nbsp;804 (98.771%)<br>
Ilość UPC występujących na poszczególnych kanałach:<br>1. Kanał 6 - 285 (35.012%)<br>
2. Kanał 11 - 282 (34.644%)<br>
3. Kanał 1 - 232 (28.501%)<br>
4. Kanał 8 - 3 (0.369%)<br>
5. Kanał 2 - 2 (0.246%)<br>
6. Kanał 10 - 2 (0.246%)<br>
7. Kanał 9 - 2 (0.246%)<br>
8. Kanał 13 - 2 (0.246%)<br>
9. Kanał 4 - 1 (0.123%)<br>
10. Kanał 3 - 1 (0.123%)<br>
11. Kanał 12 - 1 (0.123%)<br>
12. Kanał 7 - 1 (0.123%)<br>
<!-- środek - koniec -->
</div>
        <div id="pietro5" class="pietro5">Copyright &copy; 2010-2011 <a href="http://adamziaja.com" target="_blank">Adam Ziaja</a>. All rights reserved.</div>
        <!-- <div id="pietro6" class="pietro6"><a href="http://validator.w3.org/check?uri=referer">Valid HTML 4.01 Strict</a>, <a href="http://jigsaw.w3.org/css-validator/check?uri=referer&amp;profile=css3">Valid CSS level 3</a></div> -->
    <!-- blok - koniec -->
    </div>
<!-- stat - początek -->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-21262994-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<!-- stat - koniec -->
</body>
</html>
