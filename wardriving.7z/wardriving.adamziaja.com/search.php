<?php
    $pR2truDrAw = true;     // tajna zmienna potrzebna do zainkludowania plików
	include 'inc/gora.php';

	/*echo "<pre>";
	var_dump($_REQUEST);
	echo "</pre>";*/

	// sprawdzamy, czy zmienna $submit jest pusta
	if (empty($_POST['submit']) && empty($_POST['street'])) {
		// wyświetlamy formularz
		echo "<div style=\"text-align:center;\">Wyszukiwarka sieci - wypełnij <b>jedno</b> z pól:<br>
	<form method=\"post\" action=\"?\">
	<div style=\"padding-top:1em;padding-bottom:0.5em\">BSSID (adres MAC):</div>
	<div><input type=\"text\" name=\"bssid\" size=\"26\" maxlength=\"50\"></div>
	<div style=\"padding-top:1em;padding-bottom:0.5em\">SSID (nazwa sieci):</div>
	<div><input type=\"text\" name=\"ssid\" size=\"26\" maxlength=\"50\"></div>
        <div style=\"padding-top:1em;padding-bottom:0.5em\">Nazwa ulicy na której znaleziono sieć:</div>
        <div><input type=\"text\" name=\"address\" size=\"26\" maxlength=\"50\"></div>
        <div style=\"padding-top:1em;padding-bottom:0.5em\">im więcej wpisanych znaków tym większy limit</div>
	<div style=\"padding-top:1em\"><input type=\"submit\" name=\"submit\" value=\"Szukaj\"></div>
	</form></div>\n";
	}
	elseif (!empty($_POST['bssid'])) {

		$bssid=mysql_real_escape_string(htmlspecialchars(addslashes($_POST['bssid']),ENT_QUOTES));
		$bssid=str_replace('%', '\%', $bssid);
		$bssid=str_replace('_', '\_', $bssid);
		$bssid=str_replace('-', ':', $bssid);

		$bssidstrlen=strlen($bssid);
		//echo '$bssidstrlen='.$bssidstrlen."<br>";
		$bssidlimit=$bssidstrlen*10;
		if($bssidlimit>100){$bssidlimit=100;}
		//echo '$bssidlimit='.$bssidlimit."<br>";

		$query="SELECT * FROM wardriving WHERE bssid like '%".$bssid."%' LIMIT ".$bssidlimit."";
		$result=mysql_query($query);
		$num=mysql_num_rows($result);
		if($num>0) {
			$i=0;
			echo "<!-- Copyright © Adam Ziaja. All Rights Reserved. -->\n";

			$query="INSERT INTO log (ip,date,error,request,string) VALUES('".$_SERVER['REMOTE_ADDR']."','".date('Y-m-d H:i:s')."','n','".addslashes($_SERVER['REQUEST_URI'])."','".addslashes($_POST['bssid'])."')";
			mysql_query($query);

			while ($i<$num) {
				$bssid=mysql_result($result,$i,"bssid");
				$ssid=htmlspecialchars(mysql_result($result,$i,"ssid"),ENT_QUOTES);
				$seen=mysql_result($result,$i,"seen");
				$numer=$i;
		        $numer++;
				echo "$numer. <a href=\"ap.php?bssid=$bssid\">$bssid</a> $ssid ($seen)<br>\n";
			$i++;
			}
			echo "<i>limit $bssidlimit wyników</i>";
			echo "<br><div style=\"text-align:center;\"><a href=\"?\">&laquo;&nbsp;wróć</a></div>";
		}
		else {
			// logowanie błędu
			$query="INSERT INTO log (ip,date,error,request,string) VALUES('".$_SERVER['REMOTE_ADDR']."','".date('Y-m-d H:i:s')."','y','".addslashes($_SERVER['REQUEST_URI'])."','".addslashes($_POST['bssid'])."')";
			mysql_query($query);
			echo "<div style=\"text-align:center;\" class=\"czerwony\">W bazie nie ma takiego BSSID.<br><br><a href=\"?\">&laquo;&nbsp;wróć</a></div>";
		}
	}
	elseif (!empty($_POST['ssid'])) {

		$ssid=mysql_real_escape_string(htmlspecialchars(addslashes($_POST['ssid']),ENT_QUOTES));
		$ssid=str_replace('%', '\%', $ssid);
		$ssid=str_replace('_', '\_', $ssid);

		$ssidstrlen=strlen($ssid);
		//echo '$ssidstrlen='.$ssidstrlen."<br>";
		$ssidlimit=$ssidstrlen*10;
		if($ssidlimit>100){$ssidlimit=100;}
		//echo '$ssidlimit='.$ssidlimit."<br>";

		$query="SELECT * FROM wardriving WHERE ssid = '".$ssid."' OR ssid like '%".$ssid."%' LIMIT ".$ssidlimit."";
		$result=mysql_query($query);
		$num=mysql_num_rows($result);
		if($num>0) {
			$i=0;
			echo "<!-- Copyright © Adam Ziaja. All Rights Reserved. -->\n";

			$query="INSERT INTO log (ip,date,error,request,string) VALUES('".$_SERVER['REMOTE_ADDR']."','".date('Y-m-d H:i:s')."','n','".addslashes($_SERVER['REQUEST_URI'])."','".addslashes($_POST['ssid'])."')";
			mysql_query($query);

			while ($i<$num) {
				$bssid=mysql_result($result,$i,"bssid");
				$ssid=htmlspecialchars(mysql_result($result,$i,"ssid"),ENT_QUOTES);
				$seen=mysql_result($result,$i,"seen");
				$numer=$i;
		        $numer++;
				echo "$numer. <a href=\"ap.php?bssid=$bssid\">$bssid</a> $ssid ($seen)<br>\n";
			$i++;
			}
			echo "<i>limit $ssidlimit wyników</i>";
			echo "<br><div style=\"text-align:center;\"><a href=\"?\">&laquo;&nbsp;wróć</a></div>\n";
		}
		else {
			// logowanie błędu
			$query="INSERT INTO log (ip,date,error,request,string) VALUES('".$_SERVER['REMOTE_ADDR']."','".date('Y-m-d H:i:s')."','y','".addslashes($_SERVER['REQUEST_URI'])."','".addslashes($_POST['ssid'])."')";
			mysql_query($query);
			echo "<div style=\"text-align:center;\" class=\"czerwony\">W bazie nie ma takiego SSID.<br><br><a href=\"?\">&laquo;&nbsp;wróć</a></div>\n";
		}
	}

	elseif (!empty($_POST['address'])) {

		$address=mysql_real_escape_string(htmlspecialchars(addslashes($_POST['address']),ENT_QUOTES));
		$address=str_replace('%', '\%', $address);
		$address=str_replace('_', '\_', $address);

		$addressstrlen=strlen($address);
		//echo '$addressstrlen='.$addressstrlen."<br>";
		$addresslimit=$addressstrlen*10;
		if($addresslimit>100){$addresslimit=100;}
		//echo '$addresslimit='.$addresslimit."<br>";

		//$query="SELECT DISTINCT * FROM wardriving WHERE address = '".$address."' OR address like '%".$address."%' LIMIT ".$addresslimit."";
		$query="SELECT DISTINCT address FROM wardriving WHERE address like '%".$address."%,%,%' LIMIT ".$addresslimit."";
		$result=mysql_query($query);
		$num=mysql_num_rows($result);
		if($num>0) {
			$i=0;
			echo "<!-- Copyright © Adam Ziaja. All Rights Reserved. -->\n";

			$query="INSERT INTO log (ip,date,error,request,string) VALUES('".$_SERVER['REMOTE_ADDR']."','".date('Y-m-d H:i:s')."','n','".addslashes($_SERVER['REQUEST_URI'])."','".addslashes($_POST['address'])."')";
			mysql_query($query);

			//echo "<form method=\"post\" action=\"?\">\n";
			while ($i<$num) {
				$address=htmlspecialchars(mysql_result($result,$i,"address"),ENT_QUOTES);
				//$seen=mysql_result($result,$i,"seen");
				$numer=$i;
		        $numer++;
				echo "$numer. <form method=\"post\" action=\"?\" style=\"display:inline\"><input type=\"hidden\" name=\"street\" value=\"$address\"><a href=\"#\" onClick=\"document.forms[$i].submit()\">$address</a></form><br>\n";
			$i++;
			}
			//echo "</form>\n";
			echo "<i>limit $addresslimit wyników</i>";
			echo "<br><div style=\"text-align:center;\"><a href=\"?\">&laquo;&nbsp;wróć</a></div>\n";
		}
		else {
			// logowanie błędu
			$query="INSERT INTO log (ip,date,error,request,string) VALUES('".$_SERVER['REMOTE_ADDR']."','".date('Y-m-d H:i:s')."','y','".addslashes($_SERVER['REQUEST_URI'])."','".addslashes($_POST['address'])."')";
			mysql_query($query);
			echo "<div style=\"text-align:center;\" class=\"czerwony\">W bazie nie ma takiej nazwy ulicy.<br><br><a href=\"?\">&laquo;&nbsp;wróć</a></div>\n";
		}
	}

	elseif (!empty($_POST['street'])) {

		$street=mysql_real_escape_string(htmlspecialchars(addslashes($_POST['street']),ENT_QUOTES));
		$street=str_replace('%', '\%', $street);
		$street=str_replace('_', '\_', $street);

		$streetstrlen=strlen($street);
		//echo '$streetstrlen='.$streetstrlen."<br>";
		$streetlimit=$streetstrlen*10;
		if($streetlimit>100){$streetlimit=100;}
		//echo '$streetlimit='.$streetlimit."<br>";

		$query="SELECT * FROM wardriving WHERE address like '".$street."' LIMIT ".$streetlimit."";
		$result=mysql_query($query);
		$num=mysql_num_rows($result);
		if($num>0) {
			$i=0;
			echo "<!-- Copyright © Adam Ziaja. All Rights Reserved. -->\n";

			$query="INSERT INTO log (ip,date,error,request,string) VALUES('".$_SERVER['REMOTE_ADDR']."','".date('Y-m-d H:i:s')."','n','".addslashes($_SERVER['REQUEST_URI'])."','".addslashes($_POST['street'])."')";
			mysql_query($query);

			while ($i<$num) {
				$bssid=mysql_result($result,$i,"bssid");
				$ssid=htmlspecialchars(mysql_result($result,$i,"ssid"),ENT_QUOTES);
				$seen=mysql_result($result,$i,"seen");
				$numer=$i;
		        $numer++;
				echo "$numer. <a href=\"ap.php?bssid=$bssid\">$bssid</a> $ssid ($seen)<br>\n";
			$i++;
			}
			//echo "<i>limit $streetlimit wyników</i>";
			echo "<br><div style=\"text-align:center;\"><a href=\"?\">&laquo;&nbsp;wróć</a></div>\n";
		}
		else {
			// logowanie błędu
			$query="INSERT INTO log (ip,date,error,request,string) VALUES('".$_SERVER['REMOTE_ADDR']."','".date('Y-m-d H:i:s')."','y','".addslashes($_SERVER['REQUEST_URI'])."','".addslashes($_POST['street'])."')";
			mysql_query($query);
			echo "<div style=\"text-align:center;\" class=\"czerwony\">Błąd!<br><br><a href=\"?\">&laquo;&nbsp;wróć</a></div>\n";
		}
	}

include 'inc/dol.php';
?>
